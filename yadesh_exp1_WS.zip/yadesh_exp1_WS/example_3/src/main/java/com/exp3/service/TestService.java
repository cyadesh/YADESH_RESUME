package com.exp3.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.exp3.dto.TestContainerDto;

@Service
public class TestService {
	
	
	public String testServiceMethod(){
		return "Congratulations!! Service Class Invoked";
	}
	
	public void testContainerMethod(TestContainerDto tcd){
		System.out.println("The value of Var1 is:- "+tcd.getVar1());
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List testListMethod(){
		List li = new ArrayList();
		li.add("a1");
		li.add("b1");
		li.add("c1");
		li.add("d1");
		
		return li;
	}
}
