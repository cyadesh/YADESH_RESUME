package com.exp3.test_1;

import java.util.*;

public class TestExp1 {
	

		@SuppressWarnings({ "rawtypes", "unchecked" })
		public static void main (String[] args) {
			//code
			TestExp1 gobj = new TestExp1();
			List totalList1a = new ArrayList();
			List totalList1b = new ArrayList();
			List totalList1 = new ArrayList();
			List totalList2 = new ArrayList();
			List totalList3 = null;
			List totalList_all = new ArrayList();
			totalList1a = gobj.methodA();
			totalList1b = gobj.methodA();
			totalList1.add(totalList1a);
			totalList1.add(totalList1b);
			int i = 0;
			Iterator itr = totalList1.iterator();
			while(itr.hasNext() && i < totalList1.size()){
				totalList3 = new ArrayList();
				totalList2 = (List) totalList1.get(i);
				totalList3.add(((List) totalList1.get(i)).get(0));
				totalList3.add(((List) totalList1.get(i)).get(1));
				totalList3.add(((List) totalList1.get(i)).get(2));
				totalList3.add(((List) totalList2.get(4)).get(0));
				totalList3.add(((List) totalList2.get(4)).get(1));
				totalList3.add(((List) totalList2.get(4)).get(2));
				totalList_all.add(totalList3);
				i++;
			}
			//totalList3.add(totalList1);
			//totalList3.add(totalList2);
			//totalList.addAll(gobj.methodA());
			//totalList.addAll(gobj.methodB());
			System.out.println("Hello World");
			System.out.println(totalList_all);
			/*System.out.println(totalList.size());
			System.out.println(totalList.get(3));*/
		//	System.out.println(((List) totalList1.get(4)).get(0));
			
		}
		
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public List methodA(){
			TestExp1 gobj1 = new TestExp1();
			//gobj1.methodB();
		    List listA = new ArrayList();
		    List listsub = new ArrayList();
		    listsub.add("A1");
		    listsub.add("A2");
		    listsub.add("A3");
		    listA.add(1);
		    listA.add(2);
		    listA.add(3);
		    listA.add(listsub);
		    listA.add(gobj1.methodB());
		    return listA;
		}
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public List methodB(){
		    List listB = new ArrayList();
		    listB.add("B1");
		    listB.add("B2");
		    listB.add("B3");
		    return listB;
		}
	
}
