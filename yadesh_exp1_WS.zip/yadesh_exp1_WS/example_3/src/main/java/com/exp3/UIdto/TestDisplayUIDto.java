package com.exp3.UIdto;

public class TestDisplayUIDto {

	public String testNamePath;
	
	public String testListPath;

	public String getTestNamePath() {
		return testNamePath;
	}

	public void setTestNamePath(String testNamePath) {
		this.testNamePath = testNamePath;
	}

	public String getTestListPath() {
		return testListPath;
	}

	public void setTestListPath(String testListPath) {
		this.testListPath = testListPath;
	}
	
	
}
