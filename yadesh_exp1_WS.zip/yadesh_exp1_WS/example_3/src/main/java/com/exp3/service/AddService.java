package com.exp3.service;

public class AddService {

	public int add(int y, int z){
		return y+z;
	}
}
