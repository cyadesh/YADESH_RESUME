package com.exp3.service;

public class ReportClass {

	public String obj1;
	
	public String obj2;
	
	public String obj3;
	
	public String obj4;
	
	public String obj5;
	
	public String obj6;
	
	public String obj7;

	public String obj8;
	
	public String obj9;
	
	public String obj10;
	
	public String getObj1() {
		return obj1;
	}

	public void setObj1(String obj1) {
		this.obj1 = obj1;
	}

	public String getObj2() {
		return obj2;
	}

	public void setObj2(String obj2) {
		this.obj2 = obj2;
	}

	public String getObj3() {
		return obj3;
	}

	public void setObj3(String obj3) {
		this.obj3 = obj3;
	}

	public String getObj4() {
		return obj4;
	}

	public void setObj4(String obj4) {
		this.obj4 = obj4;
	}

	public String getObj5() {
		return obj5;
	}

	public void setObj5(String obj5) {
		this.obj5 = obj5;
	}

	public String getObj6() {
		return obj6;
	}

	public void setObj6(String obj6) {
		this.obj6 = obj6;
	}

	public String getObj7() {
		return obj7;
	}

	public void setObj7(String obj7) {
		this.obj7 = obj7;
	}

	public String getObj8() {
		return obj8;
	}

	public void setObj8(String obj8) {
		this.obj8 = obj8;
	}

	public String getObj9() {
		return obj9;
	}

	public void setObj9(String obj9) {
		this.obj9 = obj9;
	}

	public String getObj10() {
		return obj10;
	}

	public void setObj10(String obj10) {
		this.obj10 = obj10;
	}

		
}
