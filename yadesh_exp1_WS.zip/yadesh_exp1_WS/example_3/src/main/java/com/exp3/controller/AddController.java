package com.exp3.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.exp3.UIdto.AuditViewPageUIDto;
import com.exp3.dto.VariableListDTO;
//import com.yadesh_3.example_3.App;
import com.exp3.service.ReportClass;

@Controller
public class AddController {
	
	//private ReportClass rc = new ReportClass();
	
	/*@Autowired
	private List<ReportClass> reportClasses;
	*/
	
	@Autowired
	public VariableListDTO vld;
	
	/*@Autowired
	public AuditViewPageUIDto avp;*/
	//public AuditViewPageUIDto avp;
	
	
	
	@RequestMapping("/exp3Login.htm")
	public String loginMethod(Map<String,Object> map){
		AuditViewPageUIDto avp = new AuditViewPageUIDto();
		//avp.setName("YADESH");
		map.put("auditReportUIDTO", avp);
		return "agentAuditCBOReport";
	}
	
	@RequestMapping(value="/exp3AuditReportCBO.htm", method=RequestMethod.POST)
	public String testMethod(AuditViewPageUIDto auditReportUIDTO, Map<String,Object> map,
			HttpServletRequest req, HttpServletResponse resp){
		System.out.println("This is the Controller Output");
		String audFlag = auditReportUIDTO.getAuditFlag();
		List<ReportClass> testListReportClass = vld.testMethod(auditReportUIDTO);
		testListReportClass.
		map.put("auditReportUIDTO", auditReportUIDTO);
		
		vld.testMethod(auditReportUIDTO);
		//VariableListDTO vld = new VariableListDTO();
		if(audFlag.equals("SR"))
		{
			map.put("testDto", vld.testMethod(auditReportUIDTO));
		}
		else if(audFlag.equals("GR"))
		{
			vld.initiateReport();
			map.put("genTestDto", "Report Initiated");
		}
		
		return "agentAuditCBOReport";
	}
}
