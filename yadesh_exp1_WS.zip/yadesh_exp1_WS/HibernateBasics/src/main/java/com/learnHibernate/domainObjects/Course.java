package com.learnHibernate.domainObjects;

public class Course {
	private int id;
	private String courseName;
	private int totalStudents;
	private int registeredStudents;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(int totalStudents) {
		this.totalStudents = totalStudents;
	}
	public int getRegisteredStudents() {
		return registeredStudents;
	}
	public void setRegisteredStudents(int registeredStudents) {
		this.registeredStudents = registeredStudents;
	}
	
	
}
