package com.exp2.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.exp2.UIdto.AuditViewPageUIDto;
import com.exp2.service.ReportClass;

@Component
public class VariableListDTO {
	
	@Autowired
	private List<ReportClass> reportClasses;
	
	public List<ReportClass> testMethod(AuditViewPageUIDto auditReportUIDTO){
		
		System.out.println("This is the Service Output");
		System.out.println(auditReportUIDTO.getFromDate());
		System.out.println(auditReportUIDTO.getToDate());
		return reportClasses;
		
	}
	
	public void initiateReport(){
		
		System.out.println("Report Initiated");
		
	}

	
}
