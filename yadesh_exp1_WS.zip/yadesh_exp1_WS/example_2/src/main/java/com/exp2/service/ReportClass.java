package com.exp2.service;

public class ReportClass {

	public String obj1;
	
	public String obj2;
	
	public String obj3;
	
	public String obj4;

	public String getObj1() {
		return obj1;
	}

	public void setObj1(String obj1) {
		this.obj1 = obj1;
	}

	public String getObj2() {
		return obj2;
	}

	public void setObj2(String obj2) {
		this.obj2 = obj2;
	}

	public String getObj3() {
		return obj3;
	}

	public void setObj3(String obj3) {
		this.obj3 = obj3;
	}

	public String getObj4() {
		return obj4;
	}

	public void setObj4(String obj4) {
		this.obj4 = obj4;
	}

		
}
