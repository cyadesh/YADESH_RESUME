package com.exp2.controller;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.exp2.UIdto.TestDisplayUIDto;
import com.exp2.service.TestService;

@Controller
public class TestController {

	@Autowired
	TestService testSer;
	
	private static Logger logger = Logger.getLogger(TestController.class);
	
	TestDisplayUIDto testDisplayUIdto = new TestDisplayUIDto(); 
	
	// Called when form method is POST
	@RequestMapping(value="/testSpringLogin", method=RequestMethod.POST)
	public String springTestMethodPost(@RequestParam String normalName, @RequestParam String testNamePath,
			Map<String,Object> map){
		logger.info("LOGGER HAS STARTED IN TEST CONTROLLER");
		System.out.println("The value of TestService.testServiceMethod() is:- "+testSer.testServiceMethod());
		map.put("testSpringForm", testDisplayUIdto);
		map.put("normalName", normalName);
		map.put("submitname", testNamePath);
		map.put("testList", testSer.testListMethod());
		return "showViewResolver";
	}
	
	// Called when form method is GET
	@RequestMapping(value="/testLogin", method=RequestMethod.GET)
	public String springTestMethodGet(Map<String, Object> map){
		//testDisplayUIdto = new TestDisplayUIDto();
		map.put("testSpringForm", testDisplayUIdto);
		return "display";
	}
	
}
