package com.exp2.controller;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.exp2.UIdto.AuditViewPageUIDto;
import com.exp2.dto.VariableListDTO;
import com.exp2.service.AddService;
import com.exp2.service.ReportClass;
//import com.yadesh_3.example_3.App;

@Controller
public class AddController {
	
	//private ReportClass rc = new ReportClass();
	
	/*@Autowired
	private List<ReportClass> reportClasses;
	*/
	
	@Autowired
	public VariableListDTO vld;
	
	/*@Autowired
	public AuditViewPageUIDto avp;*/
	//public AuditViewPageUIDto avp;
	
	/*@RequestMapping("/addMethod")
	public ModelAndView add(HttpServletRequest req, HttpServletResponse resp){
		//System.out.println("ADDED");
		int i = Integer.parseInt(req.getParameter("t1"));
		int j = Integer.parseInt(req.getParameter("t2"));
		//int k = i - j;
		//AddService as = new AddService();
		App ap = new App();
		int k = ap.addNumbers(i, j);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("display.jsp");
		mv.addObject("result", k);
		return mv;
	}
	
	@RequestMapping("/subMethod")
	public ModelAndView sub(HttpServletRequest req, HttpServletResponse resp){
		//System.out.println("ADDED");
		int i = Integer.parseInt(req.getParameter("t1"));
		int j = Integer.parseInt(req.getParameter("t2"));
		//int k = i - j;
		//AddService as = new AddService();
		App ap = new App();
		int k = ap.subNumbers(i, j);
		ModelAndView mv = new ModelAndView();
		mv.setViewName("display.jsp");
		mv.addObject("result", k);
		return mv;
	}*/
	
	@RequestMapping("/login")
	public String loginMethod(Map<String,Object> map){
		AuditViewPageUIDto avp = new AuditViewPageUIDto();
		avp.setName("YADESH");
		map.put("auditReportUIDTO", avp);
		return "auditView";
	}
	
	@RequestMapping(value="/auditReport", method=RequestMethod.POST)
	public String testMethod(AuditViewPageUIDto auditReportUIDTO, Map<String,Object> map,
			HttpServletRequest req, HttpServletResponse resp){
		System.out.println("This is the Controller Output");
		String audFlag = auditReportUIDTO.getAuditFlag();
		map.put("auditReportUIDTO", auditReportUIDTO);
		//VariableListDTO vld = new VariableListDTO();
		List<ReportClass> testUnique = vld.testMethod(auditReportUIDTO);
		Set abc = new HashSet();
		for(ReportClass testUnique1 : testUnique){
			abc.add(testUnique1.obj3);
			abc.add(testUnique1.obj4);
		}
		
		if(audFlag.equals("SR"))
		{
			map.put("testDto", vld.testMethod(auditReportUIDTO));
		}
		else if(audFlag.equals("GR"))
		{
			vld.initiateReport();
			map.put("genTestDto", "Report Initiated");
		}
		
		return "auditView";
	}
}
