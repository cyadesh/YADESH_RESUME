package com.wissenTech.telephone;

public class A {
	public void run(){
		
	}
}

class B extends A implements x{
	
}

interface x{
	public void run();
	public void fun();
}

//----------------------------------------------------------

abstract class D{
	public void run();
}

abstract class DConstructorTest{
	public DConstructorTest() {
		// Abstract Class can have constructor
	}
	abstract public void run();
}

//----------------------------------------------------------

class E{
	public void run(){
		
	}
}

class F extends E{
	public int run(){
		
	}
}

//----------------------------------------------------------

