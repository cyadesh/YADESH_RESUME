package com.wissenTech.telephone;

import java.util.HashMap;

public class TrickyHashMap {

	public static void main(String[] args) {
		EmployeeWissen ew1 = new EmployeeWissen(10,"A");
		EmployeeWissen ew2 = new EmployeeWissen(10,"B");
		EmployeeWissen ew3 = new EmployeeWissen(10,"C");
		EmployeeWissen ew4 = new EmployeeWissen(10,"D");
		
		HashMap<EmployeeWissen,String> hm = new HashMap<>();
		hm.put(ew1, "Test1");
		hm.put(ew2, "Test2");
		hm.put(ew3, "Test3");
		hm.put(ew4, "Test4");
		
		System.out.println(hm.size());
	}

}

class EmployeeWissen{
	public String name;
	public int age;
	
	public EmployeeWissen() {
		age = 10;
	}
	public EmployeeWissen(int age, String name) {
		this.age = age;
		this.name = name;
	}
	
	@Override
	public int hashCode(){
		return age;
	}
	
	@Override
	public boolean equals(Object obj) {
		EmployeeWissen ew = (EmployeeWissen)obj;
		return this.name.equals(ew.name);
	}
	
	
}
