package com.self.created.packageName;

public class TestPaypal {
	interface x{
		public void foo();
	}
	static class y implements x{
		public void foo(){
			System.out.println("print success");
		}
	}
	public static void main(String[] args) {
		TestPaypal.y innerObj = new TestPaypal.y();
		innerObj.foo();
	}
}

/*interface A{
    void test();
}

class C implements A{
    public void test(){
        System.out.println("sucess test");
    }
    public void check(){
        System.out.println("sucess C");
    }
}

class D{
    public static void main (String[] args) {
        A  c = new C();
        ((C)c).check();
    }
}*/

/*import java.util.*;
class Test{
    public static void main (String[] args) {
        List l = new ArrayList();
        Test t = new Test();
        Test t1 = new Test();
        l.add(t);
        l.add(t1);
        Collections.sort(l);  // Note : For Sort operation, the Object must be Comparable.
        for(int i=0; i<l.size(); i++){
            System.out.println(l.get(i));
        }
    }
}*/