package com.self.myCodeSchool.sortingAlgorithms;

import java.util.Arrays;
import java.util.List;

public class BasicSortingAlgos {

	public static void main(String[] args) {
		int[] arr = {1, 2, 7, 4, 1, 5, 3};
		insertionSort(arr, arr.length);
		// to print the resultant array after selection sort
		System.out.println("main array passed");
		for(int x : arr){
			System.out.print(x+",");
		}
	}
	
	public static void selectionSortNotInPlace(int[] arr, int size){
		Integer[] extraArray = new Integer[size];
		int tempVar = Integer.MAX_VALUE;
		for(int i =0; i<size; i++){
			int min = arr[i];
			int k = i;
			for(int j = 0; j < size; j++){
				if(arr[j] < min){
					min = arr[j];
					k = j;
				}
			}// end of inner for loop
			extraArray[i] = min;
			arr[k] = tempVar;
		}
		
		List<Integer> l = Arrays.asList(extraArray);
		System.out.println(l);
	}// end of selectionSortNotInPlace
	
	public static void selectionSortInPlace(int[] arr, int size){
		int m = size-1;
		for(int i = 0; i < m; i++){
			int min = arr[i], k = i;
			for(int j = i+1; j<size; j++){
				if(arr[j] < min){
					min = arr[j];
					k = j;
				}
			}
			if(k!=i){
				int temp = arr[k];
				arr[k] = arr[i];
				arr[i] = temp;
			}
		}
		// to print the resultant array after selection sort
		for(int x : arr){
			System.out.print(x+" ");
		}
	}// end of selectionSortInPlace...
	
	public static void bubbleSort(int[] arr, int size){
		boolean flag;
		for(int i = 0; i < size; i++){
			flag = false;
			for(int j = 0; j < size-i-1; j++){
				if(arr[j] > arr[j+1]){
					/*int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;*/
					swap(arr, j, j+1);
					flag = true;
				}
			}
			if(!flag){
				break;
			}
		}
		// to print the resultant array after bubble sort
				for(int x : arr){
					System.out.print(x+" ");
				}
	}// end of bubbleSort...
	
	public static int[] swap(int[] arr, int x, int y){
		int temp = arr[x];
		arr[x] = arr[y];
		arr[y] = temp;
		return arr;
	}// end of swap function
	
	
	public static void insertionSort(int arr[], int size){
		for(int i = 1; i < size; i++){
			int hole = i;
			int element = arr[i];
			while(hole > 0 && element < arr[hole-1]){
				arr[hole] = arr[--hole];
			}
			if(hole != i){
				arr[hole] = element;
			}
		}
		// to print the resultant array after insertion sort
		for(int x : arr){
			System.out.print(x+" ");
		}
	}
	
	
	
	
}
