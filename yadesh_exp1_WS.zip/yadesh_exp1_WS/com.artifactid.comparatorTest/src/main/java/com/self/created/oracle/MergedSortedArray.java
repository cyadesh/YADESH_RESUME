package com.self.created.oracle;

public class MergedSortedArray {

	public static void main(String[] args) {
		int arr1[] = {1,3,5,7};
		int arr2[] = {2,3,4,5,8,9};
		mergedSortedArray(arr1, arr2);
	}
	
	public static void mergedSortedArray(int[] arr1, int[] arr2){
		
		int arr1length = arr1.length;
		int arr2lenght = arr2.length;
		int resultArray[] = new int[arr1length + arr2lenght]; 
		int i = 0,j = 0,k = 0;
		while(true){
			
			if(i == arr1length || j == arr2lenght){
				break;
			}
			
			if(arr1[i] < arr2[j]){
				resultArray[k] = arr1[i];
				i++; k++; continue;
			}
			else if(arr1[i] > arr2[j]){
				resultArray[k] = arr2[j];
				j++; k++; continue;
			}
			else {
				resultArray[k] = arr2[j];
				resultArray[++k] = arr2[j];
				i++; j++; k++; continue;
			}
			
			
		}
		
		if(i == arr1length){
			for(int x = j; x < arr2lenght; x++){
				resultArray[k] = arr2[x];
				k++;
			}
		}
		else if(j == arr2lenght){
			for(int x = i; x < arr1length; x++){
				resultArray[k] = arr1[x];
				k++;
			}
		}
		
		// to display the array
		for(int x : resultArray){
			System.out.print(x + ",");
		}
	
	}// end of method

}
