package com.self.amazonAssignment;

import java.util.Scanner;

public class TestAmazon1_new {
	public static int getMostFrequent(int[] a) {

		int maxF = 0;

		int currentMaxNo = -1;

		for (int i = 0; i < a.length - 1; i++) {
			int currentMaxF = 0;

			for (int j = 1 ; j < a.length; j++) {
				if (a[i] == a[j]) {
					currentMaxF++;
				}
			}
			if (maxF < currentMaxF) {
				maxF  = currentMaxF;
				currentMaxNo = a[i];
			}
		}

		System.out.println(currentMaxNo + ": " + maxF);
		return currentMaxNo;
	}

	public static void main(String[] args) {

		/*int a[] = {1 , 3, 4, 5, 2, 2, 3, 2}; 1 3 4 5 2 2  3  2*/
		Scanner sc = new Scanner(System.in);
		String str_Arr[] = sc.nextLine().split(" ");
		int int_arr[] = new int[str_Arr.length];
		int j = 0;
		for(String s: str_Arr){
			if(s.isEmpty()){
				continue;
			}
			int_arr[j++]= Integer.parseInt(s);
		}
		getMostFrequent(int_arr);
		//System.out.println(getMostFrequent(a));
	}
}
