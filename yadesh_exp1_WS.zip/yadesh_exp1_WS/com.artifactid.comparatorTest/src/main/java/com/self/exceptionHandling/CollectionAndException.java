package com.self.exceptionHandling;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CollectionAndException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List hetroList = new ArrayList();
		hetroList.add(10);
		hetroList.add("I am String");
		hetroList.add(10f);
		hetroList.add(1011);
		hetroList.add(10.00);
		hetroList.add("I am String double Check");
		hetroList.add(11d); // note double is implicitly converted to float.
		List<Integer> listOfIntegers = new ArrayList();
		List<Float> listOfFloats = new ArrayList();
		List<String> listOfStrings = new ArrayList();
		Iterator itr = hetroList.iterator();
		while(itr.hasNext()){
			String str = itr.next().toString();
		try{
			Integer k = Integer.parseInt(str);
			//System.out.println("I am an Intger");
			listOfIntegers.add(k);
		}catch(NumberFormatException nfeInt){
			System.out.println("I am not Int because "+nfeInt);
			try{
				Float f = Float.parseFloat(str);
				//System.out.println("I am Float");
				listOfFloats.add(f);
			}catch(NumberFormatException nfeFloat){
				System.out.println("I am not float because "+nfeFloat);
				listOfStrings.add(str);
			}
		}
		
	}
		System.out.println("The List of Integers in Collection are "+listOfIntegers);
		System.out.println("The List of Floats in Collection are "+listOfFloats);
		System.out.println("The List of Strings in Collection are "+listOfStrings);
	}

}
