package com.self.dataStructures;

public class DoublyLinkedListPrac1 {

	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int data){
			this.data = data;
			prev = next = null;
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node hNode = new Node(10);
		Node sNode = new Node(2);
		Node tNode = new Node(14);
		Node fNode = new Node(5);
		
		hNode.next = sNode;
		sNode.prev = hNode;
		sNode.next = tNode;
		tNode.prev = sNode;
		tNode.next = fNode;
		fNode.prev = tNode;
		
		//System.out.println("Test DLL");
		
		DoublyLinkedListPrac1 dllp = new DoublyLinkedListPrac1();
		dllp.display(hNode);
		dllp.displayRecursive(hNode);  System.out.println();
		dllp.displayRecursiveReverse(hNode);  System.out.println();
		//dllp.reverseDLLInMemory(hNode); System.out.println();
		//dllp.reverseDLLInMemoryRecursive(hNode);
		dllp.swapNodes(10, 2, hNode);
		System.out.println("Test DLL");
	}
	
	public void swapNodes(int x, int y, Node head)
    {
        // Nothing to do if x and y are same
        if (x == y) return;
 
        // Search for x (keep track of prevX and CurrX)
        Node prevX = null, currX = head;
        while (currX != null && currX.data != x)
        {
            prevX = currX;
            currX = currX.next;
        }
 
        // Search for y (keep track of prevY and currY)
        Node prevY = null, currY = head;
        while (currY != null && currY.data != y)
        {
            prevY = currY;
            currY = currY.next;
        }
 
        // If either x or y is not present, nothing to do
        if (currX == null || currY == null)
            return;
 
        // If x is not head of linked list
        if (prevX != null)
            prevX.next = currY;
        else //make y the new head
            head = currY;
 
        // If y is not head of linked list
        if (prevY != null)
            prevY.next = currX;
        else // make x the new head
            head = currX;
 
        // Swap next pointers
        Node temp = currX.next;
        currX.next = currY.next;
        currY.next = temp;
        
        System.out.println("Swapped given nodes DLL in memory ");
		display(head);
    }
	
	/*iterative approach to reverse DLL in memory*/
	void reverseDLLInMemory(Node hNode){
		Node currentNode = hNode;
		Node tempNode = null;
		/*swap the next Node and previous node and atlast point the head pointer to last*/
		while(currentNode != null){
			tempNode = currentNode.prev;
			currentNode.prev = currentNode.next;
			currentNode.next = tempNode;
			currentNode = currentNode.prev;
		}
		if(tempNode != null){
			hNode = tempNode.prev;
			System.out.println("Reversed DLL in memory by swapping");
			display(hNode);
		}
	}
	
	
	void reverseDLLInMemoryRecursive(Node hNode){
		Node tempNode = null;
		tempNode = hNode.prev;
		hNode.prev = hNode.next;
		hNode.next = tempNode;
		if(hNode.prev == null){
			System.out.println("Reversed DLL in memory by swapping in Recursion ");
			display(hNode);
			return;
		}
		reverseDLLInMemoryRecursive(hNode.prev);
	}
	
	/*Print dll in iterative approach*/
	void display(Node hNode){
		int count = 0;
		Node currentNode = hNode;
		while(currentNode != null){
			count++;
			System.out.print(currentNode.data + "->");
			currentNode = currentNode.next;
		}
		System.out.println("     **No of Elements in doubly Linked list is "+count);
	}
	
	/*Print dll in Recursive approach*/
	void displayRecursive(Node hNode){
		Node previousNode = hNode;
		Node currentNode = hNode.next;
		System.out.print(previousNode.data + "->");
		if(currentNode == null)
			return;
		displayRecursive(currentNode);
	}
	
	/*Print dll in Reverse order in Recursive approach*/
	void displayRecursiveReverse(Node hNode){
		Node previousNode = hNode;
		Node currentNode = hNode.next;
		//System.out.print(previousNode.data + "->");
		if(currentNode == null){
			System.out.print(previousNode.data + "->");
			return;
		}
		displayRecursiveReverse(currentNode);
		System.out.print(previousNode.data + "->");
	}

}
