package com.self.creationalDesignPatterns;

public enum MySingletonUsingEnum {
	INSTANC;
	Test t;
	private MySingletonUsingEnum() {
		System.out.println("Here");
		 t = new Test();
	}

	public Test retrieveSomething() {
		return t;
	}
	
	public static void main(String[] args) {
		System.out.println("The value is "+MySingletonUsingEnum.INSTANC.hashCode());
		System.out.println("The value is "+MySingletonUsingEnum.INSTANC.hashCode());
		System.out.println("The value is "+MySingletonUsingEnum.INSTANC.t.hashCode());
		System.out.println("The value is "+MySingletonUsingEnum.INSTANC.retrieveSomething().hashCode());
	}

}

 class Test{
	  int main1() {
		return new String("abc").hashCode();
	}
}