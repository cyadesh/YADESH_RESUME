package com.self.dataStructures;

public class DoublyLinkedList {
	
	
	public static class LinkNode{
		private int data;
		private LinkNode previous;
		private LinkNode next;
		
		public LinkNode(int data){
			this.data = data;
			previous = null;
			next = null;
		}
		
		public LinkNode(LinkNode previous, int data, LinkNode next){
			this.previous = previous;
			this.data = data;
			this.next = next;
		}
	}
	
	//To display the double linked list
	public void display(LinkNode headNode){
		LinkNode current = headNode;
		while (current != null){
			System.out.print(current.data + " --> ");
			current = current.next;
		}
		    System.out.println(current);  // here current is always null
	}
	
	//To add an element at the beginning of Doubly Linked List
	public LinkNode insertAtBegin(LinkNode headNode, int data){
		
		if(headNode == null)
			return new LinkNode(data);
		
		LinkNode newNode = new LinkNode(null, data, headNode);
		headNode = newNode; // to represent first node as headNode
		return headNode;
	}
	
	//To add an element at the end of the Doubly Linked List
	public LinkNode insertAtEnd(LinkNode headNode, int data){
		
		if(headNode == null)
			return new LinkNode(data);
		
		
		LinkNode current = headNode;
		while(current.next != null){
			current = current.next;
		}
		LinkNode newNode = new LinkNode(current, data, null);
		current.next = newNode;
		return headNode;
	}
	
	//To remove an element from front of the doubly linked List
	public LinkNode removeFront(LinkNode headNode){
		headNode = headNode.next;
		headNode.previous = null;
		return headNode;
	}
	
	//To remove an element from the end of the doubly linked list
	public LinkNode removeEnd(LinkNode headNode){
		LinkNode current = headNode;
		while(current.next.next != null)
		{
			current = current.next;
		}
		current.next = null;
		return headNode;
	}
	
	//To insert an element before the specified index
	public LinkNode insertBeforeGivenIndex(LinkNode headNode, int data, int index){
		
		LinkNode current = headNode;
		int count = 0;
		LinkNode newNode = null;
		LinkNode previousNode = null;
		while(current != null){
			previousNode = current;
			current = current.next;
			count++;
			if(count == index){
				 newNode = new LinkNode(previousNode, data, current);
				 previousNode.next = newNode;
				break;
			}
		}
		return headNode;
	}
	
	//To remove an element before the specified index
		public LinkNode removeBeforeGivenIndex(LinkNode headNode, int index){
			
			LinkNode current = headNode;
			int count = 0;
			LinkNode previousNode = null;
			LinkNode previousTargetNode = null;
			while(current != null){
				previousTargetNode = current;
				
				current = current.next;
				count++;
				if(count == index)  {
					if(previousTargetNode.previous != null) {
					 previousNode = previousTargetNode.previous;
					 previousNode.next = current;
					 previousTargetNode = null;
					 break;
					}
					else{
						headNode = headNode.next;
						previousTargetNode = null;
						break;
					}
				}
			 
			}
			
			return headNode;
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkNode headNode = new LinkNode(10);
		LinkNode secondNode = new LinkNode(headNode, 5 ,null);
		LinkNode thirdNode = new LinkNode(secondNode, 14, null);
		headNode.next = secondNode;
		secondNode.next = thirdNode;
		
		DoublyLinkedList dll = new DoublyLinkedList();
		// Traversing Front and back - start
		dll.display(headNode);
		dll.display(headNode.next);
		dll.display(headNode.next.next);
		dll.display(headNode.next.next.previous);
		dll.display(headNode.next.next.previous.previous);
		// Traversing Front and back - start
		
		headNode = dll.insertAtBegin(headNode, 6);
		dll.display(headNode);
		
		headNode = dll.insertAtEnd(headNode, 36);
		dll.display(headNode);
		
		headNode = dll.removeFront(headNode);
		dll.display(headNode);
		
		headNode = dll.removeEnd(headNode);
		dll.display(headNode);
		
		headNode = dll.insertBeforeGivenIndex(headNode, 4, 1);
		dll.display(headNode);
		
		headNode = dll.removeBeforeGivenIndex(headNode, 2);
		dll.display(headNode);
		
		/*headNode = dll.removeBeforeGivenIndex(headNode, 1);
		dll.display(headNode);*/
		
	}

}
