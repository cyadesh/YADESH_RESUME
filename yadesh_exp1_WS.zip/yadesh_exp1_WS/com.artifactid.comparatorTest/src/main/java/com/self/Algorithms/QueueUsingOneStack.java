package com.self.Algorithms;

import java.util.Iterator;
import java.util.Stack;

public class QueueUsingOneStack {

	static private Stack<Integer> stk = new Stack<Integer>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueUsingOneStack qstk = new QueueUsingOneStack();
		qstk.qPush(10);
		qstk.qPush(20);
		qstk.qPush(30);
		qstk.qPush(40);
		
		qstk.displayStack();System.out.println();
		qstk.qPop();
		System.out.println("After an element is popped");
		qstk.displayStack();
		qstk.qPush(50);
		System.out.println("After an element is pushed");
		qstk.displayStack();
		qstk.qPop();
		System.out.println("After an element is popped");
		qstk.displayStack();
		
	}
	
	public void displayStack(){
		Iterator<Integer> itr = stk.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + "->");
		}
	}
	
	public void qPush(int data){
		stk.push(data);
	}
	
	public void qPop(){
		if(stk.isEmpty()){
			System.out.println("Stack is empty");
		}
		else if(stk.size() == 1){
			stk.pop();
		}
		else{
			queuePop();
		}
	}
	
	public void queuePop(){
		int x = stk.size();
		int y = stk.pop();
		if(x == 1){
			return;
		}
		queuePop();
		qPush(y);
	}

}
