package com.self.dataStructures;

public class LinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ListNode headNode = new ListNode(10);    // 10 --> NULL
		ListNode secondNode = new ListNode(8);
		ListNode thirdNode = new ListNode(14);
		ListNode fourthNode = new ListNode(7);   // 7 --> NULL
		ListNode secondNodeTemp = secondNode;
		headNode.next = secondNode;
		secondNode.next = thirdNode;
		thirdNode.next = fourthNode;  // At this step headNode has the total List Linked to it.
		
		LinkedList llObject = new LinkedList();
		llObject.display(headNode);
		headNode = llObject.insertAtBegin(headNode, 15);
		llObject.display(headNode);
		headNode = llObject.insertAtEnd(headNode, 20);
		llObject.display(headNode);
		headNode = llObject.insertNewNodeAfterGivenNode(headNode, 50, secondNodeTemp);
		llObject.display(headNode);
		headNode = llObject.deleteAtBegin(headNode);
		llObject.display(headNode);
		headNode = llObject.deleteAtEnd(headNode);
		llObject.display(headNode);
		headNode = llObject.reverseLinkedList(headNode);
		llObject.display(headNode);
	}
	
	// type declaration for Linked List
	public static class ListNode{
		private int data;
		private ListNode next;
		
		public ListNode(int data){
			this.data = data;
			this.next = null;
		}
		
		/*public void setData(int data){
			this.data = data;
		}
		public int getData(){
			return data;
		}
		public void setNext(ListNode next){
			this.next = next;
		}
		// gets the next ListNode (data,ListNode)
		public ListNode getNext(){
			return next;
		}*/
	}
	
	public ListNode insertAtBegin(ListNode headNode, int newData){
		ListNode newNode = new ListNode(newData);
		if (headNode == null)
				return newNode;
		
		newNode.next = headNode;
		
		return newNode;
	}
	
	public ListNode insertAtEnd(ListNode headNode, int newData){
		ListNode newNode = new ListNode(newData);
		if(headNode == null){
			return newNode;
		}
		ListNode current = headNode;
		while (current.next != null){
			current = current.next;
		}
		current.next = newNode;
		return headNode;
	}
	
	// To Insert a newNode after a given node
	public ListNode insertNewNodeAfterGivenNode(ListNode headNode, int newData, ListNode secondNodeTemp){
		// edge cases for headNode and secondNodeTemp have to be handled.
		ListNode newNode = new ListNode(newData);
		ListNode current = headNode;
		ListNode afterSecond = null;
		while (current != null){
			if(current.data == secondNodeTemp.data){
				afterSecond = current.next;
				current.next = newNode;
				newNode.next = afterSecond;
				
			}
			current = current.next;
		}
		return headNode;
	}
	
	// To delete a node at the beginning
	public ListNode deleteAtBegin(ListNode headNode){
		ListNode current = headNode;
		headNode = current.next;
		current = null;  // Result will be same if not assigned the current node to be NULL
		return headNode;
	}
	
	// To delete a node at the end
	public ListNode deleteAtEnd(ListNode headNode){
		ListNode current = headNode;
		while(current.next.next != null){
			current = current.next;
		}
		current.next = null;
		return headNode;
	}
	
	// To reverse a Linked List  
	public ListNode reverseLinkedList(ListNode headNode){
		ListNode current = headNode;
		ListNode previous = null;
		ListNode next = null;
		while(current != null){
			next = current.next;
			current.next = previous;
			previous = current;
			current = next;
		}
		headNode = previous;
		return headNode;
	}
	
	// To Display the Linked List as Nodes are created in Main function.
	public void display(ListNode headNode){
		if (headNode == null)
			return;
		
		ListNode current = headNode;
		while(current != null){
			System.out.print(current.data + " --> ");
			current = current.next;
		}
		System.out.println(current); // At this point current is always NULL
	}
	
	// to find the length of Linked List
	public int listLength(ListNode headNode){
		int length = 0;
		ListNode currentNode = headNode;
		while(currentNode != null){
			length++;
			currentNode = headNode.next;
		}
		return length;
	}
	
	// 

}
