package com.self.Algorithms;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class IDeserveTest1 {

	public static void main(String[] args) {
		//findOddTimesOccuredNumberInArray();
		findOddTimesOccuredNumberInArrayUsingHashMap();
	}
	
	public static void findOddTimesOccuredNumberInArray(){
		int arr[] = {2, 3, 4, 3, 1, 4, 5, 1, 4, 2, 5};
		int i = arr.length;
		int result = 0;
		for(int j = 0; j<i ; j++){
			result ^= arr[j]; 
		}
		System.out.println(result);
	}
	
	public static void findOddTimesOccuredNumberInArrayUsingHashMap(){
		Map<Integer,Integer> map = new HashMap<>();
		int arr[] = {2, 3, 4, 3, 1, 4, 5, 1, 4, 2, 5, 2};
		int i = arr.length;
		//map.put(arr[0], 1);
		for(int j = 0; j<i ; j++){
			if(map.containsKey(arr[j]))
			   map.put(arr[j], map.get(arr[j]) + 1);
			else
				map.put(arr[j], 1);
		}
		
		Set<Entry<Integer,Integer>> set = map.entrySet();
		for(Entry<Integer,Integer> e : set){
			if(e.getValue() % 2 == 0){
				continue;
			}
			else{
				System.out.println(e.getKey());
				
			}
		}
	}
}
