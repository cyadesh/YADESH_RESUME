package com.self.exceptionHandling;

public class SelfDeclaredException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8743731011711383369L;
	String message;
	public SelfDeclaredException(String x) {
		//super(x);
		message = x;
		
	}
	
	public String toString(){
		return message;
	}
}
