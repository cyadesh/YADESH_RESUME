package com.self.amazonAssignment;

import java.util.Scanner;

public class AmazonAssessment {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		int j = 0;
		while(j < i){
			System.out.println("The next int value is "+sc.nextInt());
			j++;
		}
	}
}
