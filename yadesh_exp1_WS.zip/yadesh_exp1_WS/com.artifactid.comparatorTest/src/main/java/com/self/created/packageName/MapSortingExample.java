package com.self.created.packageName;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MapSortingExample {

	/*public static void main(String[] args) {
			
		Map<Integer,String> m = new HashMap<>();
		m.put(10,"C");
		m.put(20, "B");
		m.put(30, "A");
		System.out.println("Actual Map before sorting = "+m);
		
		Map<Integer,String> keysSortedMap = sortedMapByKeys(m);
		System.out.println("Actual Map After sorting By KEYS = "+keysSortedMap);
		
		Map<Integer,String> valuesSortedMap = sortedMapByValues(m);
		System.out.println("Actual Map After sorting By VALUES = "+valuesSortedMap);
	}*/

	public static void main(String[] args) {
		
	}

	public static <K extends Comparable<K>, V extends Comparable<V>> Map<K,V> sortedMapByKeys(Map<K,V> receivedMap){
		
		List<K> list = new ArrayList<>(receivedMap.keySet());
		Collections.sort(list);
		Map<K,V> keysSortedMap = new LinkedHashMap<>();
		for(K x : list){
			keysSortedMap.put(x, receivedMap.get(x));
		}
		return keysSortedMap;
	}
	
	public static <K extends Comparable<K>, V extends Comparable<V>> Map<K,V> sortedMapByValues(Map<K,V> receivedMap){
		
		List<Entry<K,V>> list = new ArrayList<>(receivedMap.entrySet());
		
		Collections.sort(list, new Comparator<Entry<K,V>>(){

			@Override
			public int compare(Entry<K, V> o1, Entry<K, V> o2) {
				V value1 = o1.getValue();
				V value2 = o2.getValue();
				return value1.compareTo(value2);
			}
			
		});
		
		Map<K,V> valuesSortedMap = new LinkedHashMap<>();
		for(Entry<K,V> x : list){
			valuesSortedMap.put(x.getKey(), x.getValue());
		}
		return valuesSortedMap;
	}

}

class Test{
	public static void main(String[] args) {
		
		Map<Integer,String> m = new HashMap<>();
		m.put(10,"C");
		m.put(20, "B");
		m.put(30, "A");
		System.out.println("Actual Map before sorting = "+m);
		
		Map<Integer,String> keysSortedMap = MapSortingExample.sortedMapByKeys(m);
		System.out.println("Actual Map After sorting By KEYS = "+keysSortedMap);
		
		Map<Integer,String> valuesSortedMap = MapSortingExample.sortedMapByValues(m);
		System.out.println("Actual Map After sorting By VALUES = "+valuesSortedMap);
	}
}