package com.self.functionalityTest;

import java.text.ParseException;

public class TestForFunctionality {

	public static void main(String... args){
		String testNumber = "t100.2345";
		//Double testN =  100.0d;
		try{
			try{
				
			//if(!testN.isNaN())
			System.out.println("value is - " + Double.parseDouble(testNumber));
			}
			catch(NumberFormatException nfe){
				System.out.println("entered nfe");
				throw new IllegalArgumentException("Illegal Argument Captured");
			}
		}
		catch(IllegalArgumentException pe){
			System.out.println("entered pe");
			System.out.println("Execption Catched - "+ pe);
		}
		
	}
}
