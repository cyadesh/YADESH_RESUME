package com.self.Algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class CollectionAPIRules {

	public static void main(String[] args) {
		
		/*ConcurrentHashMap<Integer,String> chm = new ConcurrentHashMap<Integer,String>();
		chm.put(10, "value10");
		chm.put(11, "value11");
		chm.put(12, "value12");
		
		Set s = chm.entrySet();
		Iterator itr = s.iterator();
		while(itr.hasNext()){
			//Map.Entry<Integer,String> es = (Entry<Integer, String>) itr.next();
			//System.out.println("The key is "+es.getKey());
			
		}*/
		
		/*Sorting of Map based on descending order of keys - start*/
		Map<String,Integer> testMap = new TreeMap<String,Integer>(new Comparator<Object>(){

			@Override
			public int compare(Object o1, Object o2) {
				return -(o1.toString().compareTo(o2.toString()));
				
			}
			
		});
		testMap.put("act",12);
		testMap.put("dog", 5);
		testMap.put("tac", 12);
		testMap.put("ogd", 5);
		testMap.put("cat", 12);
		
		System.out.println("The values of Tree Map are: "+testMap);
		
		/*Sorting of Map based on descending order of keys - end*/
		
		
		List<Entry<String,Integer>> list = new ArrayList<Entry<String,Integer>>(testMap.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>(){
			
			public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
				if(o1.getValue() < o2.getValue())
					return -1;
				else if(o1.getValue() > o2.getValue())
					return 1;
				else
					return 0;
			}

			
		}); // end of collections sort
		
		System.out.println(list);
		/*Sorting of Map based on Values - end*/
		
		
	}

	
	
	

}
