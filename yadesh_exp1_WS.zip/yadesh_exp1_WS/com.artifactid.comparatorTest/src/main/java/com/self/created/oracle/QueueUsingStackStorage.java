package com.self.created.oracle;

import java.util.Stack;

public class QueueUsingStackStorage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueUsingStackStorage que = new QueueUsingStackStorage();
		que.q_push(1);
		que.q_push(2);
		que.q_push(3);
		
		System.out.println(que.q_remove());
		System.out.println(que.q_remove());
	}
	Stack<Integer> stk1 = new Stack<>();
	
	public void q_push(int item){
		
		stk1.push(item);
		
	}
	int k = 0;
	public int q_remove(){
		
		if(stk1.isEmpty()){
			return -1;
		}
		if(stk1.size() == 1){
			//System.out.println();
			k =  stk1.pop();
		}
		else{
			int i = stk1.pop();
			q_remove();
			stk1.push(i);
		}
		return k;
	}

}
