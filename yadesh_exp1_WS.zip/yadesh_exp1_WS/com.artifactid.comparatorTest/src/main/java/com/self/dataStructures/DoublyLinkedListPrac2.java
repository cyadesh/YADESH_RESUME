package com.self.dataStructures;

public class DoublyLinkedListPrac2 {

	public static void main(String[] args) {

		Node hNode = new Node(10);
		Node sNode = new Node(20);
		Node tNode = new Node(30);
		Node fNode = new Node(40);
		
		hNode.next = sNode;
		sNode.prev = hNode;
		sNode.next = tNode;
		tNode.prev = sNode;
		tNode.next = fNode;
		fNode.prev = tNode;
		
		DoublyLinkedListPrac2 dllp2 = new DoublyLinkedListPrac2();
		
		System.out.println("Doubly Linked List");
		dllp2.displayDLL(hNode);
		System.out.println();
		dllp2.reverseDLLRecursive(hNode);
		System.out.println();
		dllp2.displayDLL(hNode);
		

	}
	
	static class Node{
		int data;
		Node next;
		Node prev;
		Node(int data){
			this.data = data;
			this.next = this.prev = null;
		}
	}// end of def of Node in DLL
	
	
	Node previousNode = null;
	void reverseDLLRecursive(Node x){
		if(x == null){
			Node hNode = previousNode;
			displayDLL(hNode);
			return;
		}
		
		Node currentNode = x;
		Node nextNode = currentNode.next;
		currentNode.next = previousNode;
		currentNode.prev = nextNode;
		previousNode = currentNode;
		reverseDLLRecursive(nextNode);
	}
	
	void displayDLL(Node hNode){
		Node currentNode = hNode;
		while(currentNode != null){
			System.out.print(currentNode.data+" <-> ");
			currentNode = currentNode.next;
		}
		return;
	}

}
