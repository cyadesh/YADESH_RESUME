package com.self.created.packageName;

public class OverloadingExample {

	public static void main(String[] args) {
		AClass a = new AClass();
		//a.sum(new Integer(5), new Integer(5));
		System.out.println(a.sum(new Integer(5), new Integer(5)));
	}

}

class AClass{
	public int sum(int a, int b){
		System.out.println("Primitive method called");
		return a+b;
	}
	public int sum(Integer a, Integer b){
		System.out.println("Wrapper method called");
		return a+b;
	}
}
