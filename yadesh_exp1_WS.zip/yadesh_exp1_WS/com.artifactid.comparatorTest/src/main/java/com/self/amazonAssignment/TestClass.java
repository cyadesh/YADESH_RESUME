package com.self.amazonAssignment;

import java.util.Scanner;
import java.util.TreeMap;

public class TestClass {

	public static void main(String[] args) throws Exception{
		/*
         * Read input from stdin and provide input before running
         * Use either of these methods for input

        //BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();
        int N = Integer.parseInt(line);

        //Scanner
        Scanner s = new Scanner(System.in);
        int N = s.nextInt();

        for (int i = 0; i < N; i++) {
            System.out.println("hello world");
        }
        */
		
		/*magicOfThree(3);
		magicOfThree(13);*/
		Scanner sc = new Scanner(System.in);
		String str_arr = null;
		while(sc.hasNextLine() ){
			str_arr = sc.nextLine();
			if(str_arr.isEmpty())
				break;
			magicOfThree(Integer.parseInt(str_arr));
			
			
		}

	}
	
	public static void magicOfThree(int n){
		int count=1, rem=1;
		if(n%10 != 3){
			return;
		}
		while(rem>0)
		{
		 rem= (rem*10+1)%n; 
		 count++;
		} 
		while(count-- > 0){ 
		    
		     System.out.print("1");
		     
		 }
		 System.out.println();
	}
	
	public static void mostFrequent(){
		// read all integers of array into a 
				TreeMap<Integer,Integer> tm = new TreeMap<Integer,Integer>();
				Scanner in = new Scanner(System.in);
				Scanner scanLine = new Scanner(in.nextLine());
				
				int num, mostFrequent, temp;
				num = scanLine.nextInt();
				mostFrequent = num;
				temp = 1;
				while(true){
					if(tm.containsKey(num)){
						temp = tm.get(num);
						temp++;
						tm.put(num, temp);
						if(tm.get(num) > tm.get(mostFrequent)){
							mostFrequent = num;	
						}else if(tm.get(num) == tm.get(mostFrequent)){
							if(num < mostFrequent){
								mostFrequent = num;
							}
						}
					}else{
						tm.put(num, temp);
					}
					if(scanLine.hasNextInt()){
						num = scanLine.nextInt();
					}else{
						break;
					}
				}
				System.out.println(mostFrequent);
			
	}

}
