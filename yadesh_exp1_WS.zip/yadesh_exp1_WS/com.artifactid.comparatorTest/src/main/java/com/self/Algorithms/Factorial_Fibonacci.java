package com.self.Algorithms;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Factorial_Fibonacci {
	
	static Map<Integer,Integer> cacheMem = null;
	
	public static void main(String ... args){
		//Fibonacci Computation
		//Factorial_Fibonacci.fibonacci_Iterative(new Scanner(System.in).nextInt());  -- Usage of Scanner
		
		//Factorial_Fibonacci.fibonacci_Iterative(10);
		
		//int fiboAtGivenPos = Factorial_Fibonacci.fibonacci_recursive(6);
		//System.out.println(fiboAtGivenPos);  // To Find Fibonacci number at the specified position
		
		
		//Factorial Computation
		//Factorial_Fibonacci.factorial_Iterative(4);
		
		/*int factAtGivenTarget = Factorial_Fibonacci.factorial_Recursive(new Scanner(System.in).nextInt());
		System.out.println(factAtGivenTarget); */
		
		int fiboAtGivenPosMemo = Factorial_Fibonacci.fibonacci_recursive_Memorization(new Scanner(System.in).nextInt());
				System.out.println(fiboAtGivenPosMemo); 
				
		System.out.println("HashMap values are: "+cacheMem);
	}
	
	public static void factorial_Iterative(int targetNumber){
		int result = 1;
		for (int i = 1; i <= targetNumber; i++){
			result *= i; 
		}
		System.out.println("The factorial of "+targetNumber+" is : "+result);
	}
	
	public static int factorial_Recursive(int targetNumber){
		if (targetNumber < 0){
			return -1;   // invalid input
		}
		if (targetNumber <= 1){
			return 1;
		}
		
		return targetNumber * factorial_Recursive(targetNumber -1);
	}
	
	public static void fibonacci_Iterative(int positionNum){
		int x = 0;
		int y = 1;
		int z = 0;
		int i = 2;
		System.out.print("The Fibonacci Series is \t");
		System.out.print(x+"\t");
		System.out.print(y+"\t");
		while (i <= positionNum){
			z = x + y;
			x = y;
			y = z;
			System.out.print(z+"\t");
			i++;
		}
	}
	
	public static int fibonacci_recursive(int positionNum){
		if(positionNum <= 1){
			return positionNum;
		}
		int x = fibonacci_recursive(positionNum-1);
		int y = fibonacci_recursive(positionNum-2);
		return  x + y;
	}
	
	public static int fibonacci_recursive_Memorization(int positionNum){
	//	System.out.println("HashMap values are: "+cacheMem);
		if(cacheMem == null){
			cacheMem =  new HashMap();
	//		System.out.println("Entered");
		}
		/*if(positionNum <= 1){
			return positionNum;
		}*/
		cacheMem.put(0, 0);
		cacheMem.put(1, 1);
		int postion1 = positionNum-1;
		int postion2 = positionNum-2;
		int x = 0;
		int y = 0;
		if(cacheMem.get(postion1) != null){
			x = cacheMem.get(postion1);
		}
		else{
			cacheMem.put(postion1,fibonacci_recursive(postion1));
			//x = fibonacci_recursive(postion1);
			//System.out.println("Put in x are"+x);
			
		}
		
		if(cacheMem.get(postion2) != null){
			y = cacheMem.get(postion2);
		}
		else{
			cacheMem.put(postion2,fibonacci_recursive(postion2));
			//y = fibonacci_recursive(postion2);
			
		}
		 
		//cacheMem.put(postion1,x);
		//cacheMem.put(postion2,y);
		
		return  x + y;
	}
}
