package com.self.dataStructures;

import java.util.*;
import java.util.LinkedList;

//left subtree value must be lesser or equal to root value and right subtree value must be greater to root value
public class BinarySearchTree {
	
	// Node defination of BST - start
	static class Node{
		int data;
		Node leftChild;
		Node rightChild;
		
		public Node(int value){
			data = value;
			leftChild = null;
			rightChild = null;
		}
		
		public Node(int value, Node leftChildValue, Node rightChildValue){
			data = value;
			leftChild = leftChildValue;
			rightChild = rightChildValue;
		}
	}
	// Node defination of BST - end
	
	// Starting point of BST is this Root Node declared globally.
	private Node root;

	// Whenever we create a bst object, initially the root value will be NULL
	public BinarySearchTree() {
		this.root = null;
	}
	
	// To add or insert elements in BST
	public void add(int value) {
		// check whether root exists
		Node nodeToAdd = new Node(value);
		if (root == null) {
			root = nodeToAdd;
		} else {
			
			Node currentRootNode = root;
			traverseAndAdd(nodeToAdd, currentRootNode);
			
		}
	}
	
	public void traverseAndAdd(Node nodeToAdd, Node currentRootNode){
		if(nodeToAdd.data < currentRootNode.data){
			if(currentRootNode.leftChild == null){
				currentRootNode.leftChild = nodeToAdd;
				return;
			}
			else{
				currentRootNode = currentRootNode.leftChild;
				traverseAndAdd(nodeToAdd, currentRootNode);
			}
		}
		else if(nodeToAdd.data > currentRootNode.data){
			if(currentRootNode.rightChild == null){
				currentRootNode.rightChild = nodeToAdd;
				return;
			}
			else{
				currentRootNode = currentRootNode.rightChild;
				traverseAndAdd(nodeToAdd, currentRootNode);
			}
		}
		else{
			return;
		}
	}
	
	
	// To search for an element in BST
	boolean search(int value){
		Node currentRootNode = root;
		boolean searchResult;
		if (value == currentRootNode.data){
			return true;
		}
		searchResult = searchForValue(value, currentRootNode);
		return searchResult;
	}
	
	boolean searchRes = false;
	boolean searchForValue(int value, Node currentRootNode){
		
		
		if(value < currentRootNode.data){
			currentRootNode = currentRootNode.leftChild;
			if(currentRootNode == null){
				System.out.println("No Element Found");
				searchRes = false;
			}
			else if(currentRootNode.data == value){
				searchRes = true;
				return searchRes;
			}
			else{
				searchForValue(value,currentRootNode);
			}
		}
		
		else if(value > currentRootNode.data){
			currentRootNode = currentRootNode.rightChild;
			if(currentRootNode == null){
				System.out.println("No Element Found");
				searchRes = false;
			}
			else if(currentRootNode.data == value){
				searchRes = true;
				return searchRes;
			}
			else{
				searchForValue(value,currentRootNode);
			}
		}
		
		return searchRes;
	}
	
	//To find the minimum element in BST using recursive approach
	void findMinimumRecursive(){
		Node currentRootNode = root;
		int minElement = findMinByTraversingLeft(currentRootNode);
		System.out.println("The Mininum Element in BST Found Recursively is "+ minElement);
	}
	
	int minimumElement;
	int findMinByTraversingLeft(Node currentRootNode){
		if(currentRootNode.leftChild == null){
			minimumElement = currentRootNode.data;
			return minimumElement;
		}
		else{
			currentRootNode = currentRootNode.leftChild;
			findMinByTraversingLeft(currentRootNode);
		}
		return minimumElement;
	}
	
	//To find the maximum element in BST using iterative approach
	void findMaximumIterative(){
		Node currentRootNode = root;
		while(currentRootNode.rightChild != null){
			currentRootNode = currentRootNode.rightChild;
		}
		System.out.println("The Maximum Element in BST found Iteratively is "+ currentRootNode.data);
	}
	
	
	//To find the height of a BST
	void findHeight(){
		Node currentRootNode = root;
		int HeightOfBST = findHeightByTraversing(currentRootNode);
		System.out.println("The Height of BST from Root node is "+HeightOfBST);
	}
	
	int HeightOfBST;
	int findHeightByTraversing(Node currentRootNode){
		if(currentRootNode == null){
			return -1;
		}
		else{
			int leftNodeHeight = findHeightByTraversing(currentRootNode.leftChild);
			int rightNodeHeight = findHeightByTraversing(currentRootNode.rightChild);
			HeightOfBST = Math.max(leftNodeHeight, rightNodeHeight) + 1;
		}
		return HeightOfBST;
		
	}
	
	//Traversal of BST - BFS Breadth First Search
	void BFSTraversal(){
		if(root == null){
			System.out.println("Empty BST Tree");
			return;
		}
		Node currentRootNode = root;
		Queue<Node> q = new LinkedList<Node>();
		q.add(currentRootNode);
		while(!q.isEmpty()){
			System.out.print(q.peek().data + " -> "); // Visited Node
			currentRootNode = q.poll();
			
			if(currentRootNode.leftChild != null){
				q.add(currentRootNode.leftChild);
			}
			if(currentRootNode.rightChild != null){
				q.add(currentRootNode.rightChild);
			}
			
		}
	}
	
	//Traversal of BST in DFS - PreOrder  // root - Left Sub Tree - right Sub Tree
	void BSTPreOrder(){
		Node currentRootNode = root;
		preOrder(currentRootNode);
	}
	
	void preOrder(Node currentRootNode){
		if(currentRootNode == null){
			return;
		}
		System.out.print(currentRootNode.data + "->");
		preOrder(currentRootNode.leftChild);
		preOrder(currentRootNode.rightChild);
	}
	
	//Traversal of BST in DFS - InOrder  // Left Sub Tree - root - right Sub Tree
	void BSTInOrder(){
		Node currentRootNode = root;
		inOrder(currentRootNode);
	}
	
	void inOrder(Node currentRootNode){
		if(currentRootNode == null){
			return;
		}
		inOrder(currentRootNode.leftChild);
		System.out.print(currentRootNode.data + "->");
		inOrder(currentRootNode.rightChild);
	}
	
	//Traversal of BST in DFS - postOrder  // Left Sub Tree - right Sub Tree - root 
	void BSTPostOrder(){
		Node currentRootNode = root;
		postOrder(currentRootNode);
	}
	
	void postOrder(Node currentRootNode){
		if(currentRootNode == null){
			return;
		}
		postOrder(currentRootNode.leftChild);
		postOrder(currentRootNode.rightChild);
		System.out.print(currentRootNode.data + "->");
		
	}
	
	//To Check if the provided Binary Tree is a Binary Search Tree
	void checkBTForBST(Node testNode){
		Node currentRootNode = testNode;
		boolean checkForBST = checkBTForBST(currentRootNode, Integer.MIN_VALUE, Integer.MAX_VALUE);
		System.out.println("The given binary Tree is Binary Search Tree -> "+ checkForBST);
	}
	
	boolean testForBST = true;
	boolean checkBTForBST(Node currentRootNode, int min_value, int max_value){
		if(currentRootNode == null){
			return false;
		}
		if(currentRootNode.data > min_value && currentRootNode.data < max_value){
			if(testForBST)
			checkBTForBST(currentRootNode.leftChild, min_value, currentRootNode.data);
			if(testForBST)
			checkBTForBST(currentRootNode.rightChild, currentRootNode.data, max_value);
			
			return testForBST;
		}
		else{
			testForBST = false;
			return testForBST;
		}
		//return testForBST;
	}
	
	// Main function
	public static void main(String[] args) {
		BinarySearchTree objBinarySearchTree = new BinarySearchTree();
		objBinarySearchTree.add(20);
		objBinarySearchTree.add(10);
		objBinarySearchTree.add(40);
		objBinarySearchTree.add(60);
		objBinarySearchTree.add(100);
		
		
		//Normal formation of Binary Tree
		Node x1 = new Node(3);
		Node x2 = new Node(2);
		Node x3 = new Node(7);
		Node x4 = new Node(1);
		Node x5 = new Node(12);
		Node x6 = new Node(10);
		Node x7 = new Node(20);
		
		x1.leftChild = x2;
		x1.rightChild = x3;
		x2.leftChild = x4;
		//x4.leftChild = x5;
		x3.rightChild = x6;
		x3.leftChild = x7;
		// search for an element
		/*boolean searchResult = objBinarySearchTree.search(60);
		System.out.println("The search result is "+searchResult);
		searchResult = objBinarySearchTree.search(61);
		System.out.println("The search result is "+searchResult);
		searchResult = objBinarySearchTree.search(10);
		System.out.println("The search result is "+searchResult);*/
		
		//Find Min and Max elments in BST
		/*objBinarySearchTree.findMinimumRecursive();
		objBinarySearchTree.findMaximumIterative();*/
		
		//To Find the Height of Tree
		/*objBinarySearchTree.findHeight();*/
		
		//Traversal of BST - Breadth First Search  or Level order Traversal
		//objBinarySearchTree.BFSTraversal();  // Time Complexity - O(n)   Space Complexity - O(1) sometimes   O(n) best/avg.
		
		//Traversal of BST - Depth First Search - PreOrder , InOrder (Sorted Traversal if Binary Tree is BST)  and PostOrder.
		System.out.println("PreOrder Traversal");
		objBinarySearchTree.BSTPreOrder();
		System.out.println();
		System.out.println("InOrder Traversal");
		objBinarySearchTree.BSTInOrder();
		System.out.println();
		System.out.println("PostOrder Traversal");
		objBinarySearchTree.BSTPostOrder();
		
		//To Check if the provided Binary Tree is a Binary Search Tree.
		System.out.println();
		objBinarySearchTree.checkBTForBST(x1);
	}
}
