package com.self.Algorithms;


public class PaypalTest{
	    public static void main (String[] args) {
	        System.out.println(new PaypalTest().powerFunction(14));
	        
	       // System.out.println(new PaypalTest().powerBitFunction(15));
	    }
	    
	    int x;
	    int y;
	    boolean z;
	    
	     boolean powerFunction(int n){
	         x = n % 2;
	        
	        if(y == 1){
	            z = true;
	        }
	        else if(x != 0){
	            z = false;
	        }
	        else{
	        	 y = n / 2;
	            powerFunction(y);
	        }
	        return z;
	    }
	     
	     
	     boolean bitFlag;
	     boolean powerBitFunction(int n){
	    	 
	    	 if (n <= 0 || (n & (n - 1)) != 0 ){
	    		 return bitFlag;
	    	 }
	    	 else  
	    		 return !bitFlag;
	     }
	
}


