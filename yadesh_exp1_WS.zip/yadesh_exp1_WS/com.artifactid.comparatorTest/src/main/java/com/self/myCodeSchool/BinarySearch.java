package com.self.myCodeSchool;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {2,4,10,10,10,18,20};
		//element to be searched is 18
		/*int index = BinarySearch.binarySearch(arr,arr.length,18);
		System.out.println("Element 18 found at index "+index);
		
		//first occ element to be searched is 10
		int firstOccIndex = BinarySearch.binarySearchFirstOccurence(arr,arr.length,10);
		System.out.println("First Occurence of Element 10 found at index "+firstOccIndex);
		
		//last occ element to be searched is 10
		int lastOccIndex = BinarySearch.binarySearchLastOccurence(arr,arr.length,10);
		System.out.println("Last Occurence of Element 10 found at index "+lastOccIndex);*/
		
		int elementCount = BinarySearch.findCountOfOccurence(arr,arr.length,10,0,arr.length-1);
		System.out.println("Count of Element 10 in Array "+elementCount);
	}
	
	public static int binarySearch(int[] arr, int length, int number){
		int low = 0;
		int high = length-1;
		int mid = 0;
		int result = -1;
		while(low<=high){
			mid = (low + high)/2;
			if(number == arr[mid]){
				result = mid;
				return result;
			}
			else if(number < arr[mid]){
				high = mid - 1;
			}
			else if(number > arr[mid]){
				low = mid + 1;
			}
		}
		return result;
	}
	
	public static int binarySearchFirstOccurence(int[] arr, int length, int number){
		int low = 0;
		int high = length-1;
		int mid = 0;
		int result = -1;
		while(low<=high){
			mid = (low + high)/2;
			if(number == arr[mid]){
				result = mid;
				high = mid - 1;
			}
			else if(number < arr[mid]){
				high = mid - 1;
			}
			else if(number > arr[mid]){
				low = mid + 1;
			}
		}
		return result;
	}
	
	public static int binarySearchLastOccurence(int[] arr, int length, int number){
		int low = 0;
		int high = length-1;
		int mid = 0;
		int result = -1;
		while(low<=high){
			mid = (low + high)/2;
			if(number == arr[mid]){
				result = mid;
				low = mid + 1;
			}
			else if(number < arr[mid]){
				high = mid - 1;
			}
			else if(number > arr[mid]){
				low = mid + 1;
			}
		}
		return result;
	}
	
	private static int count;
	public static int findCountOfOccurence(int[] arr, int length, int number, int low, int high){
		
		if(low > (length - 1) || high < 0){
			return -1;
		}
		int mid = (low + high)/2;
		if(number == arr[mid]){
			count++;
		}
		else if(number < arr[mid]){
			high = mid - 1;
		}
		else{
			low = mid + 1;
		}
		
		high = mid -1;
		findCountOfOccurence(arr, length, number, low, high);
		low = mid + 1;
		findCountOfOccurence(arr, length, number, low, high);
		/*else if(number < arr[mid]){
			high = mid - 1;
			findCountOfOccurence(arr, length, number, low, high);
		}
		else{
			low = mid + 1;
			findCountOfOccurence(arr, length, number, low, high);
		}*/
		return count;
	}
}
