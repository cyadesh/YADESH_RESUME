package com.self.created.packageName;

public class UserDefinedExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			throw new NoSuchItemFoundException("Hey Runtime Exception Thrown");
		
		
	}

}

class NoSuchItemFoundException extends RuntimeException{
	//private String message;
	public NoSuchItemFoundException(String message){
		super(message);
	}
	
	/*@Override
	public String getMessage() {
		return this.message;
	}*/
}
