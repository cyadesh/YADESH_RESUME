package com.self.creationalDesignPatterns;

public class FactoryPatternJDev {

	public static void main(String[] args) {
		
		Computer pcComputer = ComputerFactory.getInstance("PC", "4GB", "250GB", "1.5hz");
		Computer serverComputer = ComputerFactory.getInstance("Server", "20GB", "500TB", "4.5hz");
		
		System.out.println(pcComputer);
		System.out.println(serverComputer);
	}

}// end of test Client for ComputerFactory

//required methods to create a Computer(SUPER CLASS) -- may be laptop or pc or server...
abstract class Computer{
	
	public abstract String getRAM();
	public abstract String getHDD();
	public abstract String getCPU();
	
	@Override
	public String toString(){
		return "RAM = "+this.getRAM()+", HDD = "+this.getHDD()+", CPU = "+this.getCPU();
	}

}// end of Computer Class


//SUB CLASS - PC that extends SUPER CLASS Computer..
class PC extends Computer{
	
	public String RAM;
	public String HDD;
	public String CPU;
	
	public PC(String RAM, String HDD, String CPU){
		this.RAM = RAM;
		this.HDD = HDD;
		this.CPU = CPU;
	}
	
	@Override
	public String getRAM() {
		return RAM;
	}

	@Override
	public String getHDD() {
		return HDD;
	}

	@Override
	public String getCPU() {
		return CPU;
	}
	
} // end of SUB CLASS - PC 

//SUB CLASS - Server that extends SUPER CLASS Computer..
class Server extends Computer{
	
	public String RAM;
	public String HDD;
	public String CPU;
	
	public Server(String RAM, String HDD, String CPU){
		this.RAM = RAM;
		this.HDD = HDD;
		this.CPU = CPU;
	}
	
	@Override
	public String getRAM() {
		return RAM;
	}

	@Override
	public String getHDD() {
		return HDD;
	}

	@Override
	public String getCPU() {
		return CPU;
	}
	
} // end of SUB CLASS - PC 


// Creating ComputerFactory Class where the PC or Server Objects gets Ready .. i.e., instantiated 
// The methods in this ComputerFactory Class gets exposed to Client..
class ComputerFactory{
	
	public static Computer getInstance(String type, String RAM, String HDD, String CPU){
		if(type == "PC"){
			return new PC(RAM,HDD,CPU);
		}
		else if(type == "Server"){
			return new Server(RAM,HDD,CPU);
		}
		
		return null;
	}
}// end of ComputerFactory class..
