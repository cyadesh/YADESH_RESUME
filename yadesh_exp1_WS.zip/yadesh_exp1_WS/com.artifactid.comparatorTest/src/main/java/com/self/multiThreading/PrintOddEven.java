package com.self.multiThreading;

public class PrintOddEven {
	
	
	static boolean firstChance = true;
	static int i = 1;
	
	public static void main(String[] args) throws InterruptedException {
		
		final PrintOddEven poe = new PrintOddEven();
		
		Thread todd = new Thread(new Runnable(){
			
			public void run(){
				
				while(true){
					
						if(i <= 10){
							if(i%2 != 0){
								synchronized(poe){   
									System.out.print(i+"-Todd,");
									i++;
									try {
										poe.wait();
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
								}
							}
							
						}
						else{
							break;
						}
					//}// end of synch block
				}// end of for loop
			}// end of run method
		});
		
		Thread teven = new Thread(new Runnable(){
			
			public void run(){
				while(true){
					
					if(i <= 10){
						
							if(i%2 == 0){
								synchronized(poe){
								System.out.print(i+"-Teven,");
								i++;
								poe.notify();
								//firstChance = false;
								/*try {
									wait();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}*/
								}
							}
							/*else{
								System.out.print(i+",");
								notify();
							}*/
						}
						else{
							break;
						}
						
					//}// end of synch block
				}// end of for loop
			}// end of run method
		});
		
		/*Thread todd = new Thread(new Runnable(){
			
			public void run(){
				
				for(int i =1; i <=10; i+= 2){
					synchronized(this){   
						
						if(firstChance){
							firstChance = false;
							System.out.println(i+",");
							try {
								wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						else{
							System.out.println(i+",");
							firstChance = false;
							notify();
						}
					}// end of synch block
				}// end of for loop
			}// end of run method
		});
		
		Thread teven = new Thread(new Runnable(){
			
			public void run(){
				for(int i =2; i <=10; i+= 2){
					synchronized(this){
						
						if(firstChance){
							firstChance = false;
							try {
								wait();
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						else{
							System.out.print(i+",");
							notify();
						}
					}// end of synch block
				}// end of for loop
			}// end of run method
		});*/

	todd.start();
	teven.start();
	
	}

}
