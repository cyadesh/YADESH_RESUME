package com.self.creationalDesignPatterns;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializedSingletonTest {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {

		SerializedSingleton ssInstanceOne = SerializedSingleton.getInstance();
		SerializedSingleton ssInstanceTwo = null;
		
		ObjectOutput objOut = new ObjectOutputStream(new FileOutputStream("singletonSerial.ser"));
		objOut.writeObject(ssInstanceOne);
		objOut.close();
		
		ObjectInput objIn = new ObjectInputStream(new FileInputStream("singletonSerial.ser"));
		ssInstanceTwo = (SerializedSingleton) objIn.readObject();
		objIn.close();
		
		System.out.println(ssInstanceOne.hashCode());
		System.out.println(ssInstanceTwo.hashCode());
	}

}

class SerializedSingleton implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private static final SerializedSingleton ss = new SerializedSingleton();
	
	private SerializedSingleton(){ } 
	
	public static SerializedSingleton getInstance(){
		return ss;
	}
	
	//This method is used to get the same object after de-serialization
	protected Object readResolve(){
		return getInstance();
	}
}
