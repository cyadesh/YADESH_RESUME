package com.self.dataStructures;

public class LinkedListPrac1 {
	
	static class LinkNode{
		int data;
		LinkNode next;
		LinkNode(int data){
			this.data = data;
			next = null;
		}
	}
	
	 LinkNode headNode = null;
			
	public static void main(String[] args) {
		
		LinkedListPrac1 llp1 = new LinkedListPrac1();
		// form the linked list
		llp1.initializeLinkedList();
		//to display the formed linked list
		llp1.display();  				System.out.println();
		llp1.printReverseLLRecursive(); System.out.println();
		llp1.display();					System.out.println();
		llp1.printReverseLLRecursive(llp1.initializeLinkedList()); System.out.println();
		llp1.display();					System.out.println();
		llp1.ReverseLLRecursive(llp1.initializeLinkedList()); System.out.println();
		llp1.display();					System.out.println();
	}
	
	// to form linked list
	LinkNode initializeLinkedList(){
		headNode = new LinkNode(10);
		LinkNode secondNode = new LinkNode(2);
		LinkNode thirdNode = new LinkNode(5);
		LinkNode fourthNode = new LinkNode(1);
		// form linked list
		headNode.next = secondNode;
		secondNode.next = thirdNode;
		thirdNode.next = fourthNode;
		return headNode;
	}
	
	// print the linked list in reverse order without effecting the order and       WITHOUT method argument
	void printReverseLLRecursive(){
		LinkNode currentNode = headNode;
		if(headNode == null) return;
		headNode = currentNode.next;
		printReverseLLRecursive();
		headNode = currentNode;
		System.out.print(currentNode.data+" ");
	}
	
	// print the linked list in reverse order without effecting the order and       WITH method argument
	void printReverseLLRecursive(LinkNode hNode){
		if(hNode == null) return;
		printReverseLLRecursive(hNode.next);
		System.out.print(hNode.data + " ");
		return;
	}
	
	//linked list in reverse order - RECURSIVELY
	void ReverseLLRecursive(LinkNode hNode){
		LinkNode previousNode = null;
		if(hNode.next == null){
			headNode = hNode;
			return;
		}
		previousNode = hNode;
		hNode = hNode.next;
		ReverseLLRecursive(hNode);
		hNode.next = previousNode;
		previousNode.next = null;
		return;
	}
	
	void display(){
		
		LinkNode currentNode = headNode;
		while(currentNode != null){
			System.out.print(currentNode.data+"->");
			currentNode = currentNode.next;
		}
		    System.out.print(currentNode);
		return;
	}
	
	

}
