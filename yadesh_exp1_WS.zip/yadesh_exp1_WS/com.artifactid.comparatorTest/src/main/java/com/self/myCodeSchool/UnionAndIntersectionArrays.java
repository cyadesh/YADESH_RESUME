package com.self.myCodeSchool;

public class UnionAndIntersectionArrays {

	public static void main(String[] args) {
		int arr1[] = {1,3,4,5,7};
		int arr2[] = {2,3,5,6};
		UnionAndIntersectionArrays.unionArrays(arr1, arr2);
	}
	
	public static void unionArrays(int[] arr1, int[] arr2){
		int a1_len = arr1.length;
		int a2_len = arr2.length;
		int i = 0, j = 0, k = 0;
		int arr_3[] = new int[10];
		while(i<a1_len && j<a2_len){
			if(arr1[i]<arr2[j]){
				arr_3[k] = arr1[i];
				i++; k++;
			}
			else if(arr1[i]>arr2[j]){
				arr_3[k] = arr2[j];
				j++; k++;
			}
			else{
				arr_3[k] = arr1[i];
				i++; j++; k++;
			}
		}
		
		if(i != a1_len){
			for(int h = i; h<a1_len; h++){
				arr_3[k]= arr1[h];
				k++;
			}
		}
		else if(j != a2_len){
			for(int h = j; h<a2_len; h++){
				arr_3[k]= arr2[h];
				k++;
			}
		}
		System.out.println("The values after union of two arrays are:");
		for(int x:arr_3){
			System.out.print(x+",");
		}
	}

}
