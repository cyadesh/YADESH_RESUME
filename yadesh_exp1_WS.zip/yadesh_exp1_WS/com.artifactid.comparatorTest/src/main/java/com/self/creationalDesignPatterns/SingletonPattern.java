package com.self.creationalDesignPatterns;

public class SingletonPattern {
	
	 static class Singleton {
		private static final Singleton instance = new Singleton();

		private Singleton() {
		}

		public static Singleton getSingleInstance() {
			return instance;
		}

	}
	
	public static void main(String[] args) {
	//	SingletonPattern sp = new SingletonPattern();
		/*System.out.println(Singleton.instance.hashCode());
		System.out.println(Singleton.getSingleInstance().instance.hashCode());
		System.out.println(Singleton.instance.hashCode());*/
		
		/*System.out.println(SingletonTest.st);
		System.out.println(SingletonTest.getSingletonTestObject().hashCode());
		System.out.println(SingletonTest.st.hashCode());
		System.out.println(SingletonTest.getSingletonTestObject().hashCode());*/
		
		System.out.println(SingletonTestEager.ste);
		System.out.println(SingletonTestEager.getSingletonTestObject().hashCode());
		System.out.println(SingletonTestEager.ste.hashCode());
		System.out.println(SingletonTestEager.getSingletonTestObject().hashCode());
	}
}

class SingletonTest{
	public static SingletonTest st ;
	private SingletonTest(){
		System.out.println("I have entered here");
	}
	
	public  static SingletonTest getSingletonTestObject(){
		if(st == null){
			st = new SingletonTest();
		}
		return st;
	}
}

class SingletonTestEager{
	public static SingletonTestEager ste = new SingletonTestEager() ;
	private SingletonTestEager(){
		System.out.println("I have entered here by Eager Loading");
	}
	
	public  static SingletonTestEager getSingletonTestObject(){
		
		return ste;
	}
}



