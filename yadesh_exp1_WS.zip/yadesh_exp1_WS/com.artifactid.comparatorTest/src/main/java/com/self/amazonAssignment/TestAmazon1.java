package com.self.amazonAssignment;

import java.util.Scanner;
import java.util.TreeMap;

public class TestAmazon1 {

	public static void main(String[] args) {
		TreeMap<Integer,Integer> tm = new TreeMap<Integer,Integer>();
		Scanner in = new Scanner(System.in);
		Scanner scanLine = new Scanner(in.nextLine());
		
		int num, mostFrequent, temp;
		num = scanLine.nextInt();
		mostFrequent = num;
		temp = 1;
		while(true){
			if(tm.containsKey(num)){
				temp = tm.get(num);
				temp++;
				tm.put(num, temp);
				if(tm.get(num) > tm.get(mostFrequent)){
					mostFrequent = num;	
				}else if(tm.get(num) == tm.get(mostFrequent)){
					if(num < mostFrequent){
						mostFrequent = num;
					}
				}
			}else{
				tm.put(num, temp);
			}
			if(scanLine.hasNextInt()){
				num = scanLine.nextInt();
			}else{
				break;
			}
		}
		System.out.println(mostFrequent);

	}

}
