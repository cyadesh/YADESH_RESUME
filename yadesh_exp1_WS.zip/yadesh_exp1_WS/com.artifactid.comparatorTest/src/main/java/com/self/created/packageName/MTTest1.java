package com.self.created.packageName;

import java.util.LinkedList;
import java.util.List;



public class MTTest1 {

	public static void main(String[] args) {
		final List<Integer> pcl = new LinkedList<Integer>();
		ProdcuerThread pt = new ProdcuerThread(pcl);
		ConsumerThread ct = new ConsumerThread(pcl);
		pt.start();
		ct.start();
	}

}

class ProdcuerThread extends Thread{
	public final List<Integer> pl;
	
	ProdcuerThread(List<Integer> pl){
		this.pl = pl;
	}
	@Override
	public void run(){
		for(int i=0; i<3;i++){
			synchronized(pl){
				if(pl.isEmpty() || pl.size()<=3){
					pl.add(i);
					System.out.println("Producer Thread Added - "+i);
					pl.notify();
				}
			}//end of synch block
		}//end of for loop
	}
}

class ConsumerThread extends Thread{
	public final List<Integer> cl;
	
	ConsumerThread(List<Integer> cl){
		this.cl = cl;
	}
	@Override
	public void run(){
		int index = 0;
		while(true){
			synchronized(cl){
				if(!cl.isEmpty()){
					int removedElement = cl.remove(0);
					System.out.println("consumer Thread Removed - "+removedElement);
					index++;
					cl.notify();
				}
				else{
					if(index == 3)
						break;
					else{
						try {
							cl.wait();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}//end of synch block
		}//end of while loop
	}
}
