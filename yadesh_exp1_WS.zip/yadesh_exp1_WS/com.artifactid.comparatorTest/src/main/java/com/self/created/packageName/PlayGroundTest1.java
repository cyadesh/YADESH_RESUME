package com.self.created.packageName;

import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.jws.soap.SOAPBinding;

public class PlayGroundTest1 {

	String test = "test";
	
	
	
	public String getTest() {
		return test;
	}



	public void setTest(String test) {
		this.test = test;
		String x = "Test";
	}



	public static void main(String[] args) {
		int x = 4;
		//x++;
		/*System.out.println((x++ * 4));
		
		final PlayGroundTest1 pgt = new PlayGroundTest1();
		pgt.setTest("A");
		
		System.out.println(pgt.test);*/
		
		/*List<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		
		System.out.println(list);
		System.out.println("First Element is "+list.get(0));
		System.out.println("Removed Element is "+list.remove(0));
		System.out.println("First Element is "+list.get(0));
		System.out.println(list);*/
		
			
			/*final int mostNegative = Integer.MIN_VALUE;
			System.out.println(mostNegative);
			System.out.println(Math.abs(Integer.MIN_VALUE));
			final int negated = Math.abs(mostNegative);
			System.out.println(negated);
			*/
			//List<Integer> list = new LinkedList<>();
		
		swapStrings();
	}
	
	private final String x = "test";
	
	private static void test(int n) throws Exception{
		if(n < 0){
			throw new Exception();
		}
	}
	
	private static void swapStrings(){
		String s1 = "abc";
		String s2 = "wxyz";
		s1 = s1.concat(s2);
		s2 = s1.substring(0, s1.length()-s2.length());
		s1 = s1.substring(s2.length(), s1.length());
		System.out.println("Value of s1- "+s1+" & s2- "+s2);
	}
	

}
