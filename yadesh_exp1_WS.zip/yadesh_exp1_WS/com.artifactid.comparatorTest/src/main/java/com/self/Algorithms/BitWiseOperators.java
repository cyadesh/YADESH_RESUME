package com.self.Algorithms;

public class BitWiseOperators {

	public static void addTwoNumbers(int a, int b)
	{
		while (b != 0){
			int carry = a & b;
			a = a ^ b;
			b = carry << 1;
		}
		System.out.println("Addition of a and b is "+a);
	}
	public static void main(String[] args) {
		BitWiseOperators.addTwoNumbers(2, 3);
	}

}
