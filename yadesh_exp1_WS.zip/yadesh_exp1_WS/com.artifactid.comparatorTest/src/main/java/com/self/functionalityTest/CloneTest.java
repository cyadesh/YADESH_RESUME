package com.self.functionalityTest;

import java.util.HashMap;
import java.util.Iterator;

public class CloneTest implements Cloneable {

	private int id;

	private String name;

	private HashMap props;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HashMap getProps() {
		return props;
	}

	public void setProps(HashMap props) {
		this.props = props;
	}

	//Uncomment for Deep Cloning.. 
	/*public CloneTest clone() {
		System.out.println("invoking overridden clone method");
		HashMap hm = new HashMap();
		String key;
		Iterator it = this.props.keySet().iterator();
		// Deep Copy of field by field
		while (it.hasNext()) {
			key = (String) it.next();
			hm.put(key, this.props.get(key));
		}
		CloneTest ct = new CloneTest();
		ct.setId(this.id);
		ct.setName(this.name);
		ct.setProps(hm);
		return ct;
	}*/

	public static void main(String[] args) throws CloneNotSupportedException {

		CloneTest ct1 = new CloneTest();
		ct1.setId(1);
		ct1.setName("first");
		HashMap hm = new HashMap();
		hm.put("1", "first");
		hm.put("2", "second");
		hm.put("3", "third");
		ct1.setProps(hm);
		// Using default clone() implementation
		CloneTest ct2 = (CloneTest) ct1.clone();
		CloneTest ct3 = ct1;
		// Check whether the ct1 and ct2 attributes are same or different
		System.out.println("ct1 and ct2 HashMap == test: " + (ct1.getProps() == ct2.getProps()));
		// Lets see the effect of using default cloning i.e., Shallow Cloning
		ct1.getProps().put("4", "fourth");
		System.out.println("ct2 props:" + ct2.getProps());
		ct1.setName("new");
		System.out.println("ct2 name:" + ct2.getName());
		System.out.println("ct3 name:" + ct3.getName());

	}

}

/*So it�s clear that default clone function uses Shallow copy and ct2 is affected by any change in the ct1 attributes 
and we need to override Object's Clone Method.
Note 1:- if we change the String (name) attribute in ct1,
Since String is an immutable class and its implementation is different from normal classes, 
when you will change the name of ct1 object, it will start referring to some other object and cloned object will be unaffected.
Note 2:- If your Class contains mutable objects, then you need to provide the proper implementation of clone() function 
that uses �Deep Copy�.
*/



