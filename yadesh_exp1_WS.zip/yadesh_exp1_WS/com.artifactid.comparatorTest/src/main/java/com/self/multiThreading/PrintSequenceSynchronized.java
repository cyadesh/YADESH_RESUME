package com.self.multiThreading;

public class PrintSequenceSynchronized {

	public static void main(String[] args) {
		Thread1 tR = new PrintSequenceSynchronized().new Thread1();
		Thread t1 = new Thread(tR);
		Thread t2 = new Thread(tR);
		t1.setName("Thread_1");
		t2.setName("Thread_2");
		
		t1.start();
		t2.start();
	}
	private static int k1;
	private static int k2;
	
	class Thread1 implements Runnable {

		  private volatile boolean evenFlag = true;   

		  public void run() { 
			  Thread.currentThread();
			  synchronized(this){
				  Thread.currentThread();
		        if (evenFlag == true) {  
		              printEven();
						            try {
										wait();
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
		        } else {      
		              printOdd();
		              notifyAll();
		        }  
			  }
		  }  
		  
		  
		  public void printEven() {    
			  Thread.currentThread();
		       while(k1<=10){
		              System.out.println(k1+" "); 
		              k1 = k1 + 1;
		              break;
		        }  
		        evenFlag = false;  
		  }  
		  
		 
		  public  void printOdd() {  
			  Thread.currentThread();
		        while(k1<=10) {  
		              System.out.println(k1+" ");  
		              k1 = k1 + 1;
		              break;
		        }  
		        evenFlag = true;          
		  }  
		}

}
