package com.self.created.packageName;

import java.util.ArrayList;
import java.util.List;

public class CompareTwoObjects {
	
	public static void main(String [] args){
		
		EmployeeObject_A empObj_A_1 = new CompareTwoObjects().new EmployeeObject_A();
		Address add_A_1 = new CompareTwoObjects().new Address();
		add_A_1.setDoorNo(11);
		add_A_1.setStreetName("1_A_StreetName");
		add_A_1.setCityName("1_A_CityName");
		empObj_A_1.setEmpNo_A(1);
		empObj_A_1.setEmpName_A("1_A");
		empObj_A_1.setEmpAge_A(25);
		empObj_A_1.setDeptName_A("1_A_deptName");
		empObj_A_1.setAddress_A(add_A_1);
		
		EmployeeObject_A empObj_A_2 = new CompareTwoObjects().new EmployeeObject_A();
		Address add_A_2 = new CompareTwoObjects().new Address();
		add_A_2.setDoorNo(12);
		add_A_2.setStreetName("2_A_StreetName");
		add_A_2.setCityName("2_A_CityName");
		empObj_A_2.setEmpNo_A(2);
		empObj_A_2.setEmpName_A("2_A");
		empObj_A_2.setEmpAge_A(26);
		empObj_A_2.setDeptName_A("2_A_deptName");
		empObj_A_2.setAddress_A(add_A_2);
		
		EmployeeObject_A empObj_A_3 = new CompareTwoObjects().new EmployeeObject_A();
		Address add_A_3 = new CompareTwoObjects().new Address();
		add_A_3.setDoorNo(13);
		add_A_3.setStreetName("3_A_StreetName");
		add_A_3.setCityName("3_A_CityName");
		empObj_A_3.setEmpNo_A(3);
		empObj_A_3.setEmpName_A("3_A");
		empObj_A_3.setEmpAge_A(27);
		empObj_A_3.setDeptName_A("3_A_deptName");
		empObj_A_3.setAddress_A(add_A_3);
		
		EmployeeObject_B empObj_B_1 = new CompareTwoObjects().new EmployeeObject_B();
		Address add_B_1 = new CompareTwoObjects().new Address();
		add_B_1.setDoorNo(21);
		add_B_1.setStreetName("3_A_StreetName");
		add_B_1.setCityName("1_B_CityName");
		empObj_B_1.setEmpNo_B(3);
		empObj_B_1.setEmpName_B("1_B");
		empObj_B_1.setDeptName_B("1_B_deptName");
		empObj_B_1.setAddress_B(add_B_1);
		
		Address add_B_2 = new CompareTwoObjects().new Address(22,"1_A_StreetName","2_B_CityName");
		EmployeeObject_B empObj_B_2 = new CompareTwoObjects().new EmployeeObject_B(1,"2_B","2_B_deptName",add_B_2);
		//System.out.println(add_B_2);
		//System.out.println(empObj_B_2);
		List<EmployeeObject_A> empList_A = new ArrayList<EmployeeObject_A>();
		empList_A.add(empObj_A_1);
		empList_A.add(empObj_A_2);
		empList_A.add(empObj_A_3);
		
		List<EmployeeObject_B> empList_B = new ArrayList<EmployeeObject_B>();
		empList_B.add(empObj_B_1);
		empList_B.add(empObj_B_2);
		
		for(EmployeeObject_A x_A : empList_A){
			for(EmployeeObject_B x_B : empList_B){
				if((x_A.getEmpNo_A() == x_B.getEmpNo_B()) && (x_A.getAddress_A().getStreetName().equals(x_B.getAddress_B().getStreetName()))){
					System.out.println(x_A);
				}
			}
		}
	}
	
	class EmployeeObject_A{
		
		private int empNo_A;
		private String empName_A;
		private int empAge_A;
		private String deptName_A;
		private Address address_A;
		
		public int getEmpNo_A() {
			return empNo_A;
		}
		public void setEmpNo_A(int empNo_A) {
			this.empNo_A = empNo_A;
		}
		public String getEmpName_A() {
			return empName_A;
		}
		public void setEmpName_A(String empName_A) {
			this.empName_A = empName_A;
		}
		public int getEmpAge_A() {
			return empAge_A;
		}
		public void setEmpAge_A(int empAge_A) {
			this.empAge_A = empAge_A;
		}
		public String getDeptName_A() {
			return deptName_A;
		}
		public void setDeptName_A(String deptName_A) {
			this.deptName_A = deptName_A;
		}
		public Address getAddress_A() {
			return address_A;
		}
		public void setAddress_A(Address address_A) {
			this.address_A = address_A;
		}
		@Override
		public String toString() {
			return "EmployeeObject_A [empNo_A=" + empNo_A + ", empName_A=" + empName_A + ", empAge_A=" + empAge_A
					+ ", deptName_A=" + deptName_A + ", address_A=" + address_A + "]";
		}
			
		
	}
	
	class EmployeeObject_B{
		
		private int empNo_B;
		private String empName_B;
		
		private String deptName_B;
		private Address address_B;
		
		public EmployeeObject_B(){
			
		}
		
		public EmployeeObject_B(int empNo_B, String empName_B, String deptName_B, Address address_B) {
			super();
			this.empNo_B = empNo_B;
			this.empName_B = empName_B;
			this.deptName_B = deptName_B;
			this.address_B = address_B;
		}
		public int getEmpNo_B() {
			return empNo_B;
		}
		public void setEmpNo_B(int empNo_B) {
			this.empNo_B = empNo_B;
		}
		public String getEmpName_B() {
			return empName_B;
		}
		public void setEmpName_B(String empName_B) {
			this.empName_B = empName_B;
		}
		/*public int getEmpAge_B() {
			return empAge_B;
		}
		public void setEmpAge_B(int empAge_B) {
			this.empAge_B = empAge_B;
		}*/
		public String getDeptName_B() {
			return deptName_B;
		}
		public void setDeptName_B(String deptName_B) {
			this.deptName_B = deptName_B;
		}
		public Address getAddress_B() {
			return address_B;
		}
		public void setAddress_B(Address address_B) {
			this.address_B = address_B;
		}

		@Override
		public String toString() {
			return "EmployeeObject_B [empNo_B=" + empNo_B + ", empName_B=" + empName_B + ", deptName_B=" + deptName_B
					+ ", address_B=" + address_B + "]";
		}
		
		
		
	}
	
	class Address{
		private int doorNo;
		private String streetName;
		private String cityName;
		
		public Address(){
			
		}
		public Address(int doorNo, String streetName, String cityName) {
			super();
			this.doorNo = doorNo;
			this.streetName = streetName;
			this.cityName = cityName;
		}
		public int getDoorNo() {
			return doorNo;
		}
		public void setDoorNo(int doorNo) {
			this.doorNo = doorNo;
		}
		public String getStreetName() {
			return streetName;
		}
		public void setStreetName(String streetName) {
			this.streetName = streetName;
		}
		public String getCityName() {
			return cityName;
		}
		public void setCityName(String cityName) {
			this.cityName = cityName;
		}
		@Override
		public String toString() {
			return "Address [doorNo=" + doorNo + ", streetName=" + streetName + ", cityName=" + cityName + "]";
		}
		
		
	}
	
	
}
