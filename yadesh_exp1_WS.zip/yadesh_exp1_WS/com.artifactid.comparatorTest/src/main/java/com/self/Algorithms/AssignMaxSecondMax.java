package com.self.Algorithms;

public class AssignMaxSecondMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AssignMaxSecondMax ams = new AssignMaxSecondMax();
		int arr[] = {5,1,3,9,7};
		System.out.println("The Maximum element in the array is "+ams.max(arr));
		System.out.println("The Second Maximum element in the array is "+ams.secondMax(arr));
		
		for(int x : arr){
			System.out.print(x + ","); // To check if the array got distorted or not...
		}
	}
	
	public int max(int []arr){
		int max = arr[0];
		int i = 1, n = arr.length;
		while(i < n){
			if(max < arr[i])
				max = arr[i];
			
			i++;
		}
		
		return max;
	}
	
	public int secondMax(int []arr1){
		int []arr2 = arr1;
		int max1 = max(arr2);
		int max2 = -1, i = 0, n = arr2.length;
		while(i < n){
			if(max1 == arr2[i]){
				  i++;	
				  continue;
				}
			/*if(max1 == arr2[i]){
				arr2[i] = Integer.MIN_VALUE;
			}*/  /* This makes the main passed array distorted*/
			if(max2 < arr2[i])
				max2 = arr2[i];
			i++;
		}
		return max2;
	}
}
