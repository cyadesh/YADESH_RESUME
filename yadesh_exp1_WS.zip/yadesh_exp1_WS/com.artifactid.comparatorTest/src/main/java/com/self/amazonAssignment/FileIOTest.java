package com.self.amazonAssignment;

import java.util.Scanner;

public class FileIOTest {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String firstLine[] = sc.nextLine().split(" ");
		int i = Integer.parseInt(firstLine[0]); // number of input lines
		int j = Integer.parseInt(firstLine[1]); // number of input integers
		//String str = sc.nextLine();
		String str_arr = null;
		int int_arr[] = new int[j];
		String str_arr_temp[] = null;
		int h = 0;
		while(sc.hasNextLine() ){
			str_arr = sc.nextLine();
			if(str_arr.isEmpty())
				break;
			str_arr_temp = str_arr.split("\\s");
			for(String s : str_arr_temp){
				int_arr[h] = Integer.parseInt(s);
				h++;
			}
			
			
		}
		System.out.println("Finished");
	}
  /*
3 8
1
2 3
4 5 6 7 8

3
13
	
	   */
}
