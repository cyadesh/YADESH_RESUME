package com.self.javaTrickyConcepts;

public class TestClass {

	TestClass(){
		System.out.println("Test Class got Accessed");
	}
	
	public void testMethod(){
		System.out.println("Test Method got Accessed");
	}
	
	//TestClass tc = new TestClass(); // Results in Stack OverFlow .. as soon as Main Method founds TestClass it starts to load the class and this makes the class to be 
	                                // called recursively, as TestClass here is an instance variable.
	static TestClass tc = new TestClass(); // This is will be loaded once for the class.. and doesnot lead to Stack overflow.
	
	public static void main(String[] args) {

		TestClass tc = new TestClass();
		
		tc.testMethod();
	}

}
