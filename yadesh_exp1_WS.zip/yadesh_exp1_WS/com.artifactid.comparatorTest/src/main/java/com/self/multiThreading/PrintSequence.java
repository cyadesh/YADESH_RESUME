package com.self.multiThreading;

import java.util.ArrayList;
import java.util.List;

public class PrintSequence {

	public static void main(String[] args) {
		final List<Integer> al = new ArrayList<>();
		PrintSequence ps = new PrintSequence();
		PrintOdd po = ps.new PrintOdd(al);
		PrintEven pe = ps.new PrintEven(al);
		
		po.start();
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pe.start();
		
		//System.out.println(al);
	}
	
	class PrintOdd extends Thread{
		final List<Integer> list;
		boolean test = true;
		PrintOdd(List<Integer> list){
			this.list = list;
		}
		
		public void run(){
			try {
				PrintOdd.sleep(10);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			synchronized (list) {
				
				while(test){
				while(list.size()%2==0){
					try {
						list.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
					list.add(list.size());
					System.out.print(list.size()+" ");
					if(list.size() == 10)
						test = false;
				}
			}
		}
	}

	class PrintEven extends Thread{
		final List<Integer> list;
		PrintEven(List<Integer> list){
			this.list = list;
		}
		
		public void run(){
			synchronized (list) {
				
				while(list.size()%2==0){
					list.add(list.size());
					System.out.print(list.size()+" ");
					list.notify();
					
				}
					
				
			}
		}
	}


}// end of outer class

