package com.self.Algorithms;

public class MultiThreadingMCQ implements Runnable {

	int x, y;
	public void run() {
		for(int i=0; i<5; i++){
			synchronized(this){
				x = 12;
				y = 12;
			}
			System.out.print(x+" "+y+" ");
		}
	}
 
	public static void main(String[] args) {
		MultiThreadingMCQ mt = new MultiThreadingMCQ();
		Thread t1 = new Thread(mt);
		Thread t2 = new Thread(mt);
		
		t1.start();
		t2.start();
	}
}


