package com.self.dataStructures;

public class StackLinkedList {

	static class LinkNode{
		String data;
		LinkNode next;
		LinkNode(String data){
			this.data = data;
			next = null;
		}
	}
	public static void main(String[] args) {
		
		StackLinkedList sll = new StackLinkedList();
		
		sll.nodesInitializer();
		
		sll.iterateLLForPush();
		
	}
	
	//for stack emptiness 
	static int count = 0;
	
	//headNode of Linked List
	LinkNode headNode = null;
	
	//headNode of Stack Linked List
	LinkNode stackHeadNode = null;
	
	// Nodes initializer
	void nodesInitializer(){
		headNode = new LinkNode("a");
		LinkNode secondNode = new LinkNode("b");
		LinkNode thirdNode = new LinkNode("c");
		//form linked list
		headNode.next = secondNode;
		secondNode.next = thirdNode;
		displayLL(headNode); System.out.println();
	}
	
	// display Linked List
	void displayLL(LinkNode hNode){
		LinkNode currentNode = hNode;
		while(currentNode!=null){
			System.out.print(currentNode.data+" -> ");
			currentNode = currentNode.next;
		}
		    System.out.print(currentNode);
	}
	
	//Method to iterate over linked list and send each node to push operation
	void iterateLLForPush(){
		LinkNode currentNode = headNode;
		while(currentNode != null){
			push(currentNode.data);
			currentNode = currentNode.next;
		}
		displayLL(stackHeadNode); System.out.println();
		pop();
		displayLL(stackHeadNode); System.out.println();
		pop();
		displayLL(stackHeadNode); System.out.println();
		pop();
		displayLL(stackHeadNode); System.out.println();
		pop();
	}
	
	//push operation of stack
	void push(String data){
		LinkNode tempNode = new LinkNode(data);
			if(count == 0){
				stackHeadNode = tempNode;
				count++;
			}
			else{
				tempNode.next = stackHeadNode;
				stackHeadNode = tempNode;
				count++;
			}
	}
	
	//pop Operation of stack
	void pop(){
		LinkNode currentNode = stackHeadNode;
		if(count == 0){
			System.out.println("Stack is empty");
		}
		else{
			stackHeadNode = currentNode.next;
			currentNode = null;
			count--;
		}
	}
}
