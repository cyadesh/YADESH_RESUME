package com.self.Algorithms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class PyramidPattern {
	
	public static String[]  initMethod(){
		
				BufferedReader in
				   = new BufferedReader(new InputStreamReader(System.in));
				String line = null;
				try {
					 line = in.readLine();
				} catch (IOException e) {
					// TODO Auto-generated catch block // put logs
					e.printStackTrace();
				}
				String[] lineArray = line.split(" ");
				// TODO Auto-generated method stub
				/*Scanner sc = new Scanner(System.in);
				sc.useDelimiter(" ");
				System.out.println("Second Input Strings are "+sc.next()+" and "+sc.next());
				sc.close();*/
		return lineArray;
	}
	
	
//	    *
//	   **
//	  ***
//	 ****
	public void pattern1(String var, int noOfRows){
		for(int i=0; i<=noOfRows; i++){
			
			for(int j=0; j<=noOfRows; j++){
				if(j>=noOfRows-i)
					System.out.print(var);
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	
	
//	    *
//	   ***
//	  *****
//	 *******
	public void pattern2(String var, int noOfRows){
		for(int i=0; i<=noOfRows; i++){
			
			for(int j=0; j<=noOfRows; j++){
				if(j>=noOfRows-i)
					System.out.print(var);
				else
					System.out.print(" ");
			}
			for(int h=0 ; h<i; h++){
				System.out.print(var);
			}
			System.out.print("\n");
		}
	}
	
	
//	   *
//	  * *
//	 * * *
//	* * * *
	public void pattern3(String var, int noOfRows){
		for(int i=0; i<=noOfRows; i++){
			boolean testEscape = true;
			for(int j=0; j<=noOfRows; j++){
				
					if(j>=noOfRows-i){
						if(testEscape){
							System.out.print(var);
							testEscape = false;
						}
						else
						{
							System.out.print(" ");
							testEscape = true;
						}
					}
					else
						System.out.print(" ");
			}
			
			if(i%2!=0)
				testEscape = true;
			else
				testEscape = false;
			
				for(int h=0 ; h<i; h++){
					if(testEscape){
						System.out.print(var);
						testEscape = false;
					}
					else
					{
						System.out.print(" ");
						testEscape = true;
					}
				}
				System.out.print("\n");
			}
			
		}
	

	public static void main(String[] args) {
		
		String[] inputLineArray = PyramidPattern.initMethod();
		
		PyramidPattern pp = new PyramidPattern();
		
		/*System.out.println("test1 for lineFeed - \\n");
		System.out.print("test2");*/
		
		/*pp.pattern1(inputLineArray[0], Integer.parseInt(inputLineArray[1]));
		
		pp.pattern2(inputLineArray[0], Integer.parseInt(inputLineArray[1]));
		
		pp.pattern3(inputLineArray[0], Integer.parseInt(inputLineArray[1]));*/
		
		pp.patternTest2(inputLineArray[0], Integer.parseInt(inputLineArray[1]));
	}
	
//    *
//   ***
//  *****
// *******
		public void patternTest2(String var, int noOfRows){
			
			int i = 0, j = noOfRows-1;
			for(i = 0; i < noOfRows; i++){
				
				for(j = noOfRows -1; j >=0; j--){
					System.out.print(var);
					int k = noOfRows-j-1;
					if(k == i){
						break;
					}
				}
				
				System.out.println();
			}
		}
		
		
		
		
		
}
