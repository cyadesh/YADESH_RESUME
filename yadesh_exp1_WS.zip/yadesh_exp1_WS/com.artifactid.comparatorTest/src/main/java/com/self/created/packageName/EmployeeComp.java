package com.self.created.packageName;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

public class EmployeeComp implements Comparable<Object>{
	
	int empNo;
	String empName;
	
	EmployeeComp(int empNo, String empName){
		this.empName = empName;
		this.empNo = empNo;
	}

	public int compareTo(Object o) {
		EmployeeComp e2 = (EmployeeComp)o;
		int eNo2 = e2.empNo;
		String eName2 = e2.empName;
		if(this.empNo < eNo2){
			return 1;
		}
		else if(this.empNo > eNo2){
			return -1;
		}
		else{
			return -this.empName.compareTo(eName2);
		}
	}
	
	
	/*public boolean equals(EmployeeComp obj) { // custom equals method as the arguments are different wrt Object's equals method..
		if(!(obj instanceof EmployeeComp)) return false;
		EmployeeComp e2 = (EmployeeComp)obj;
		int eNo2 = e2.empNo;
		String eName2 = e2.empName;
		if(this.empNo == eNo2){
			if(this.empName == eName2){
				return true;
			}
		}
		return false;
	}*/
	
	@Override
	public boolean equals(Object obj) { // Actual Object's equals method Overriden method.. 
		if(!(obj instanceof EmployeeComp)) return false;
		EmployeeComp e2 = (EmployeeComp)obj;
		int eNo2 = e2.empNo;
		String eName2 = e2.empName;
		if(this.empNo == eNo2){
			if(this.empName == eName2){
				return true;
			}
		}
		return false;
	}
	
	@Override
	public int hashCode() {
		return 31 * (this.empNo + this.empName.hashCode());
	}
	
	@Override
	public String toString() {
		return "EmpNo = "+this.empNo+" & EmpName = "+this.empName;
	}
	
	public static void main(String[] args) {
		/*EmployeeComp e1 = new EmployeeComp(2, "Emp 2");
		EmployeeComp e2 = new EmployeeComp(1, "Emp 5");
		EmployeeComp e3 = new EmployeeComp(1, "Emp 1");
		EmployeeComp e4 = new EmployeeComp(3, "Emp 3");
		
		Set<EmployeeComp> st = new TreeSet<EmployeeComp>(new Comparator<Object>(){

			public int compare(Object o1, Object o2) {
				EmployeeComp e1 = (EmployeeComp)o1;
				EmployeeComp e2 = (EmployeeComp)o2;
				return -e1.empName.compareTo(e2.empName);
			}
			
		});
		st.add(e1);
		st.add(e2);
		st.add(e3);
		st.add(e4);
		System.out.println(st);*/
		// The below treeset uses default Comparable(I)
		/*Set<EmployeeComp> st = new TreeSet<EmployeeComp>();
		st.add(e1);
		st.add(e2);
		st.add(e3);
		st.add(e4);
		
		System.out.println(st);*/
		/*
		// The below treeset uses default Comparator(I)
		Set<EmployeeComp> stCmpt = new TreeSet<EmployeeComp>(new EmployeeComparator());
		stCmpt.add(e1);
		stCmpt.add(e2);
		stCmpt.add(e3);
		stCmpt.add(e4);
		
		System.out.println(stCmpt);*/
		
		EmployeeComp eTest1 = new EmployeeComp(1, "Emp 1");
		//EmployeeComp eTest2 = new EmployeeComp(1, "Emp 1");
		Set<EmployeeComp> stTest = new HashSet<EmployeeComp>();
		stTest.add(new EmployeeComp(1, "Emp 1"));
		System.out.println(stTest.contains(new EmployeeComp(1, "Emp 1")));  // false :- HashSet's "contains" method uses Object's "equals" method and hence 
																			// equals method should be overridden properly as shown above
		//whereas TreeSet's contains method uses That particular class's equals method and hence work's fine.. 
		
	}
}//end of EmployeeComp class

class EmployeeComparator implements Comparator<Object>{

	public int compare(Object o1, Object o2) {
		EmployeeComp e1 = (EmployeeComp)o1;
		EmployeeComp e2 = (EmployeeComp)o2;
		int eNo1 = e1.empNo;
		int eNo2 = e2.empNo;
		String eName1 = e1.empName;
		String eName2 = e2.empName;
		if(eNo1 < eNo2){
			return -1;
		}
		else if(eNo1 > eNo2){
			return 1;
		}
		else{
			return eName1.compareTo(eName2);
		}
	}
	
}
