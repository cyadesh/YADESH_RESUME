package com.self.created.packageName;

public class PlayGround {

	 String className = this.getClass().getName();
	
	public static void main(String[] args) {
		
		/*int a[] = new int[5]; 
		
		System.out.println(a.length);*/
		String s = "A";
		int arr[] = {2,3};
		System.out.println(arr[0]);// line 1
		System.out.println(s); // line 2
		PlayGround.swap(arr, s);
		System.out.println(arr[0]); // line 3
		System.out.println(s); // line 4
	}
	
	public static void swap(int[] arr, String s){
		int temp = arr[0];
		arr[0] = arr[1];
		arr[1] = temp;
		s = "B";
		return;
	}

}




/* Name of the class has to be "Main" only if the class is public. */
class A {
	int x;
	int y;

	void m1() {
		this.x = 8;
		this.y = 9;
	}
}

class Ideone {
	public static void main(String[] args) {
		// your code goes here
		A a = new A();
		a.x = 5;
		a.y = 111;
		a.m1();
		System.out.println(a.x);
		System.out.println(a.y);
	}

}