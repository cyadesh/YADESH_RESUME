package com.self.dataStructures;

import java.util.Arrays;
import java.util.EmptyStackException;

public class StackArrayImpl<T> implements StackInterface<T> {

	/** Storage for stack */
	private T[] theData;
	
	/** Index to top of stack */
	int top = -1; // Initially empty
	
	/** Default initial capacity */
	private static final int INITIAL_CAPACITY = 10;
	
	/** capacity of stack */
	int capacity;
	
	/**
	 * Construct an empty stack with the default initial capacity.
	 */
	@SuppressWarnings("unchecked")
	public StackArrayImpl(){
		theData = (T[]) new Object[INITIAL_CAPACITY];
		capacity = INITIAL_CAPACITY;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public T push(T item) {
		// TODO Auto-generated method stub
		if(top == theData.length - 1){
			reallocate();
		}
		top++;
		theData[top]= item;
		return item;
	}

	public T peek() {
		if(empty()){
			throw new EmptyStackException();
		}
		return theData[top];
	}

	public T pop() {
		if(empty()){
			throw new EmptyStackException();
		}
		return theData[top--];//returns and delete the top element and then decrements the top index.
	}

	public boolean empty() {
		return top == -1;
	}
	
	/**
	 * Doubles array capacity.
	 */
	private void reallocate()
	{
		capacity = 2 * capacity;
		theData = Arrays.copyOf(theData, capacity);
	}

}
