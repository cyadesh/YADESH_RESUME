package com.self.redMartAssignment;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class Spreadsheet {
	
	public static class SheetCell{
		boolean isCellEvaluated;
		String cellContent;
		Double value;
		
		public SheetCell(String cellContent){
			this.cellContent = cellContent;
		}
	}
	
	SheetCell[][] sheetCells = null;
	private int rowSize;
	private int colSize;
	
		// To insert the  cell values in the spreadSheet
			private static void insertCellValues(Spreadsheet spreadSheet) {
				try
				{
				@SuppressWarnings("resource")
				Scanner sc = new Scanner(System.in);	
				
				spreadSheet.sheetCells= null;

				String[] fields = null;
				int[] size = new int[2];
				if (sc.hasNextLine()) {
					fields = sc.nextLine().split(" ");

					if (fields.length != 2) {
						throw new IllegalArgumentException("Input Size is not valid..");
					}
					else {
						for (int i = 0; i < fields.length; i++)
							size[i] = Integer.parseInt(fields[i]);
						//we got the size of the spreadsheet here, based on first line of input
						if(size[1] > 26){
							throw new IllegalArgumentException("Invalid Row Size.. MAX Expected value is 26");
						}
						spreadSheet.sheetCells = new SheetCell[size[1]][size[0]];
						spreadSheet.colSize = size[0];
						spreadSheet.rowSize = size[1];
					}

				}

				int rowIndex = 0,colIndex = 0,cellCount=0;
				while (sc.hasNextLine()) {
					String line = sc.nextLine();
					if (line.isEmpty())
						break;
					spreadSheet.sheetCells[rowIndex][colIndex] = new SheetCell(line);
						cellCount++;
					colIndex++;
					if(colIndex==spreadSheet.colSize)
					{
						colIndex = 0;
						rowIndex++;
					}
				}//end of while loop
				
				if (cellCount != size[0]*size[1])
					throw new IllegalArgumentException("No of cells doesn't match the given size..");
				
				}//end of try Block
				catch(Exception e){
			    	System.out.println(" Some issue while reading values..");
			    	System.exit(1);
			    }// exception thrown while reading values..
			} //end of insertCellValues
		

	
	// recursive call for each cell if it depends on other cell and return value when evaluation is completed.
	private Double evaluateEachCell(SheetCell sheetCell,List<SheetCell> evalList) {
		
		if(evalList == null)
		 {
			 evalList = new LinkedList<SheetCell>();
		 }
		
		if(sheetCell.isCellEvaluated)
		{
			return sheetCell.value;
			
		} else if(!sheetCell.isCellEvaluated && !evalList.contains(sheetCell))
		{
			evalList.add(sheetCell);

	        
			String[] fields = sheetCell.cellContent.split(" ");
			
	        Stack<Double> stkOperands = new Stack<Double>();

		        for(int i=0;i<fields.length;i++) {
		        	try{
		            String str = fields[i];
		            
		            if      (str.equals("+")) stkOperands.push(stkOperands.pop() + stkOperands.pop());
		            else if (str.equals("++")) stkOperands.push(stkOperands.pop() + 1);
		            else if (str.equals("--")) stkOperands.push(stkOperands.pop() - 1);
		            else if (str.equals("*")) stkOperands.push(stkOperands.pop() * stkOperands.pop());
		            else if (str.equals("/")){
		         
		            	double divisor = stkOperands.pop();
		               	double dividend = stkOperands.pop();
		               	
		            	stkOperands.push( dividend / divisor);
		            } 
		            else if (str.equals("-")){ 
		            	double subtractor = stkOperands.pop();
		               	double subtractee = stkOperands.pop();
		               	
		            	stkOperands.push( subtractee - subtractor);
		            
		            }
		            else if (isNumber(str)) stkOperands.push(Double.parseDouble(str));
		            else {
		            	SheetCell anotherCell = getCell(str);
		            	stkOperands.push(evaluateEachCell(anotherCell,evalList));
		            }
		        	}// end of try block
		        	catch(Exception e){
		        		System.out.println("May be the given Input Cell not Following RPN => "+sheetCell.cellContent);
		        		System.exit(1);
		        	}
		        }// end of for loop
		        
		        sheetCell.value = stkOperands.pop();
		        sheetCell.isCellEvaluated = true;


		} else {
			System.out.println("The Cyclic dependencies for the Cell Value -> "+sheetCell.cellContent);
			for(SheetCell loopCell:evalList)
			{
				System.out.println("Cell content : "+loopCell.cellContent+ " depends On");
			}
			System.exit(1);
		}
		
		return sheetCell.value;
	}
	
	
	//Evaluates each cell's ASCII character and decides the dependency on the other cell 
	private SheetCell getCell(String s) {
		try {
			int x = (int) s.charAt(0) % 65;
			int y = Integer.parseInt(s.substring(1, s.length())) - 1;
			return sheetCells[x][y];
		} catch (NumberFormatException e) {
			System.out.println("Data format error occurred while evaluating Cell" + s);
			System.exit(1);
		}
		return null;

	}
	
	

	 //To check if the parsed string is a number or not.
		private static boolean isNumber(String s) {
			 try {
				    Double.parseDouble(s);
				    return true;
				  }
				  catch (NumberFormatException e) {
				    // s is not numeric
				    return false;
				  }
		}

	
	// Main Function
	public static void main(String[] args){

	try{

			Spreadsheet spreadSheet = new Spreadsheet();
			
			insertCellValues(spreadSheet);
			
			for (int i = 0; i < spreadSheet.rowSize; i++) {
				for (int j = 0; j < spreadSheet.colSize; j++) {
					spreadSheet.evaluateEachCell(spreadSheet.sheetCells[i][j],null);
				}
			}
			System.out.println(spreadSheet.colSize+" "+spreadSheet.rowSize);
			for (int i = 0; i < spreadSheet.rowSize; i++) {
				for (int j = 0; j < spreadSheet.colSize; j++) {
	
					if(i==spreadSheet.rowSize-1 && j==spreadSheet.colSize-1)
						System.out.printf("%.5f", spreadSheet.sheetCells[i][j].value);
					else
					System.out.printf("%.5f%n", spreadSheet.sheetCells[i][j].value);
				}
			}
		
		
       }catch(Exception e){
    	  e.printStackTrace();
	   }
	}
		

}