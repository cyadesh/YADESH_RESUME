package com.self.functionalityTest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateFunctionality {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yy");
		sdf.setLenient(false);
		try{
			Date date = sdf.parse("10-02-2017");
			Date date2 = new Date();
			Calendar cd = Calendar.getInstance();
			//cd.setTime(date);
			cd.add(Calendar.DAY_OF_MONTH, 1);
			cd.set(Calendar.HOUR, 00);
			cd.set(Calendar.MINUTE, 00);
			cd.set(Calendar.SECOND, 00);
			cd.set(Calendar.MILLISECOND, 00);
			
			Date testDate = new Date(cd.getTimeInMillis());
			System.out.println("Tommorow's Date is - "+testDate);
			System.out.println("Today's date2 is - "+date2);
			System.out.println("The date is - "+date);
			int k = (date).compareTo(testDate);
			if (k > 0){
				System.out.println("date is greater than testdate");
			}
			else if (k < 0){
				System.out.println("date is less than testdate");
			}
			else if (k == 0){
				System.out.println("date is equal to testdate");
			}
			
		}catch(ParseException pe){
			System.out.println("The Date Exception is - "+pe);
		}
		
	}

}
