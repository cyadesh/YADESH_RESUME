package com.self.Algorithms;

public class AssignLLOddEven {

	static class Node{
		int data;
		Node next;
		Node(int data){	
			this.data = data;
			next = null;
		}
	}
	
	public static void main(String[] args) {
		Node hNode = new Node(1);    // 10 --> NULL
		Node sNode = new Node(2);
		Node tNode = new Node(3);
		Node fNode = new Node(4);
		Node ftNode = new Node(5);
		Node stNode = new Node(6);
		
		hNode.next = sNode;
		sNode.next = tNode;
		tNode.next = fNode;
		fNode.next = ftNode;
		ftNode.next = stNode;
		
		AssignLLOddEven aoe = new AssignLLOddEven();
		aoe.display(hNode); System.out.println();
		System.out.println("After Even and Odd reordering:");
		aoe.oddEven(hNode);
		aoe.display(hNode);
	}
	
	public void oddEven(Node hNode){
		Node pOdd = null, pEven = null, odd = hNode, even = hNode.next;
		Node tempOdd = odd, tempEven = even;
		while(odd != null && even != null){
			pOdd = odd;
			pEven = even;
			odd = even.next;
			if(odd != null){
				even = odd.next;
				pEven.next = even;
			}
			pOdd.next = odd;
			if(pOdd.next == null){
				pOdd.next = tempEven;
			}
		}
		
		//display(tempOdd);  //display thru main function
		
	}
	
void display(Node hNode){
		
		Node currentNode = hNode;
		while(currentNode != null){
			System.out.print(currentNode.data+"->");
			currentNode = currentNode.next;
		}
		    System.out.print(currentNode);
		return;
	}

}
