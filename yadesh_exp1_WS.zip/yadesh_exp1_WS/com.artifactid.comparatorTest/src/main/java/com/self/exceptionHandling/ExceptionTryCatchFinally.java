package com.self.exceptionHandling;

public class ExceptionTryCatchFinally {
	
	int balan = 100;
	
	public static void main(String []args){
		int balance = 100;
		
		try{
			if(balance == 100){
				throw new SelfDeclaredException("Balance is not Proper");
			}
		}catch(SelfDeclaredException sde){
			System.out.println(sde);
			System.out.println("catch block called");
		}
		
		System.out.println("Exception Handled");
		
	}
	
}
