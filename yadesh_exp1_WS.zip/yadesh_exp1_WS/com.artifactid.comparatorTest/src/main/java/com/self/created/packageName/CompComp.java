package com.self.created.packageName;

import java.util.HashSet;
import java.util.TreeSet;

public class CompComp implements Comparable{
	
	private int id;
	private String name;
	private int age;
	
	public CompComp(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public int compareTo(Object o) {
		CompComp cc = (CompComp)o;
		if(this.id < cc.id){
			return -1;
		}
		else if(this.id > cc.id){
			return +1;
		}
		else{
			return this.name.compareToIgnoreCase(cc.name);
		}
			
	}
	
	public String toString(){
		return this.id+" "+this.name+" "+this.age;
	}

	public static void main(String[] args) {
		TreeSet<CompComp> ts = new TreeSet<>(); // Uses Comparable's compareTo() method for comparison and insertion into hashtable
		ts.add(new CompComp(10,"test3",25));
		ts.add(new CompComp(9,"test5",26));
		ts.add(new CompComp(9,"test4",26));
		ts.add(new CompComp(9,"test3",26));
		ts.add(new CompComp(11,"test1",27));
		ts.add(new CompComp(10,"test3",25));
		
		System.out.println(ts);
		
		System.out.println(new CompComp(10,"test3",25).equals(new CompComp(10,"test3",25)));  // Return false, if equals() method not overridden
		
		System.out.println(new CompComp(10,"test3",25).compareTo(new CompComp(10,"test3",25))); // Return 0, though equals() method not overridden, because of CompareTo Overridden
		
		
		System.out.println(new CompComp(10,"test3",25).hashCode());
		System.out.println(new CompComp(10,"test3",25).hashCode());
		
		HashSet<CompComp> ts1 = new HashSet<>();  // Uses equals() method for comparison and insertion into hashtable
		ts1.add(new CompComp(10,"test3",25));
		ts1.add(new CompComp(9,"test5",26));
		ts1.add(new CompComp(9,"test4",26));
		ts1.add(new CompComp(9,"test3",26));
		ts1.add(new CompComp(11,"test1",27));
		ts1.add(new CompComp(10,"test3",25));
		
		System.out.println(ts1);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof CompComp)) {
			return false;
		}
		CompComp other = (CompComp) obj;
		if (age != other.age) {
			return false;
		}
		if (id != other.id) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}
	
	
	

}
