package com.in28minutes.junit.helper;

import static org.junit.Assert.*;

import org.junit.Test;

public class StringHelperTest {
	
	StringHelper helper = new StringHelper();
	
	@Test
	public void testTruncateAInFirst2Positions_1() {
		//fail("Not yet implemented");
		//below commented section is to understand expeced and actual..
		//StringHelper helper = new StringHelper();
		/*String actual = helper.truncateAInFirst2Positions("AACD");
		String expected = "CD";
		assertEquals(expected, actual);*/
		
		//by placing expected and actual inline
		assertEquals("CD",helper.truncateAInFirst2Positions("AACD"));
		/*assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
		assertEquals("CD",helper.truncateAInFirst2Positions("CDA"));*/
	}
	
	@Test
	public void testTruncateAInFirst2Positions_2() {
		//StringHelper helper = new StringHelper();
		assertEquals("CD",helper.truncateAInFirst2Positions("ACD"));
	}
	
	//ABCD => false, 
	@Test
	public void testAreFirstAndLastTwoCharactersTheSame_BasicNegativeSenario(){
		
		//assertEquals(false,helper.areFirstAndLastTwoCharactersTheSame("ABCD"));
		//or
		assertFalse(helper.areFirstAndLastTwoCharactersTheSame("ABCD"));
		
	}
	
	@Test
	public void testAreFirstAndLastTwoCharactersTheSame_BasicPositiveSenario(){
		
		assertTrue(helper.areFirstAndLastTwoCharactersTheSame("ABAB"));
		
	}
	
	@Test
	public void absoluteOfMostNegativeValue() {
	final int mostNegative = Integer.MIN_VALUE;
	final int negated = Math.abs(mostNegative);
	assertFalse(negated > 0);
	}

}
